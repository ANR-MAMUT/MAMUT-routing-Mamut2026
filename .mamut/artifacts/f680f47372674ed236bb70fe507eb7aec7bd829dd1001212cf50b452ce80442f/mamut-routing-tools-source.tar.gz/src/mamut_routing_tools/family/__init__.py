"""Benchmark-family generation: publish the whole family into a marker-rooted
collection tree (slim CVRP / VRPTW instances, shared geo / road / traffic /
distances sidecars, and the TDVRP/TDVRPTW twins of the road-graph v2 td model).

Relocated from ``mamut_routing_publish.td_generation``: generation
now lives in the generation tool. Consumes the TD bridge produced by
``mamut_routing_tools.td.traffic`` plus the stage-1 sampling intermediates from
``mamut_routing_tools.generation``.
"""

from mamut_routing_tools.td.bridge import (
    BridgeGraph,
    BridgeNodes,
    BridgeSpeeds,
    load_bridge_graph,
    load_bridge_nodes,
    load_bridge_speeds,
)
from mamut_routing_tools.family.family import (
    DEFAULT_EXTENSION_END,
    DEFAULT_SAMPLE_STEP,
    TD_HORIZON,
    TD_INTENSITIES,
    TD_MODELS,
    BuiltBase,
    BuiltTDBase,
    build_base,
    build_td,
    capacity_lower_bound,
    derive_vrptw,
    ensure_collection_root,
    materialize_distances,
    sampling_seed,
    simplify_tolerance_for,
)
from mamut_routing_tools.family.naming import (
    ALL_TW_SETS,
    EXTRA_TW_SETS,
    FAMILY,
    METHOD_TAGS,
    TW_SET_TD_SHARED,
    base_instance_name,
    family_prefix,
    subinstance_name,
    td_instance_dir,
    td_instance_name,
    vrptw_instance_name,
)

__all__ = [
    "ALL_TW_SETS",
    "EXTRA_TW_SETS",
    "TW_SET_TD_SHARED",
    "vrptw_instance_name",
    "BridgeGraph",
    "BridgeNodes",
    "BridgeSpeeds",
    "BuiltBase",
    "BuiltTDBase",
    "DEFAULT_EXTENSION_END",
    "DEFAULT_SAMPLE_STEP",
    "FAMILY",
    "METHOD_TAGS",
    "TD_HORIZON",
    "TD_INTENSITIES",
    "TD_MODELS",
    "base_instance_name",
    "family_prefix",
    "build_base",
    "build_td",
    "capacity_lower_bound",
    "derive_vrptw",
    "ensure_collection_root",
    "materialize_distances",
    "load_bridge_graph",
    "load_bridge_nodes",
    "load_bridge_speeds",
    "sampling_seed",
    "simplify_tolerance_for",
    "subinstance_name",
    "td_instance_dir",
    "td_instance_name",
]
