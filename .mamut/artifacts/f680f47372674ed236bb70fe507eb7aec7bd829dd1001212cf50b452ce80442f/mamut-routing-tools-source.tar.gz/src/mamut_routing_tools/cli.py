"""mamut-tools: command-line interface of MAMUT-routing-tools."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated, Optional

import typer

app = typer.Typer(
    name="mamut-tools",
    help="Local MAMUT-routing tool suite: OSM acquisition, road-graph engine, route geometry, and instance generation.",
    no_args_is_help=True,
    add_completion=False,
)


def _version_callback(value: bool) -> None:
    """Print the version and the package location, then exit.

    The location matters as much as the number: it distinguishes a PyPI install
    from an editable source checkout, which is the usual reason a command does
    not behave the way the docs say it should.
    """
    if not value:
        return
    from mamut_routing_tools import __version__

    typer.echo(f"mamut-tools {__version__} ({Path(__file__).parent})")
    raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        Optional[bool],
        typer.Option(
            "--version",
            "-V",
            callback=_version_callback,
            is_eager=True,
            help="Show the installed version and package location, then exit.",
        ),
    ] = None,
) -> None:
    """Entry point holding the global options; sub-commands do the work."""

roadgraph_app = typer.Typer(help="Road-graph engine (OpenStreetMapX-compatible construction).", no_args_is_help=True)
geometry_app = typer.Typer(help="BKS route-geometry materialization.", no_args_is_help=True)
osm_app = typer.Typer(help="OSM city acquisition (Nominatim + Overpass).", no_args_is_help=True)
generate_app = typer.Typer(help="Interactive CVRP/VRPTW instance generation on city road graphs.", no_args_is_help=True)
convert_app = typer.Typer(help="Converters for external benchmark distributions.", no_args_is_help=True)
app.add_typer(roadgraph_app, name="roadgraph")
app.add_typer(geometry_app, name="geometry")
app.add_typer(osm_app, name="osm")
app.add_typer(generate_app, name="generate")
app.add_typer(convert_app, name="convert")
bks_campaign_app = typer.Typer(
    help="BKS campaigns: baseline, resumable multi-solver runs, single-writer harvest, reports (TOML spec).",
    no_args_is_help=True,
)
app.add_typer(bks_campaign_app, name="bks-campaign")


def _resolve_city_osm(city: str, osm_path: Path | None, workspace: Path) -> Path:
    """The city's extract: an explicit path, else <workspace>/osmdata/<City>.osm."""
    from mamut_routing_tools.workspace import osmdata_dir

    if osm_path is not None:
        return osm_path
    candidate = osmdata_dir(workspace, create=False) / f"{city}.osm"
    if candidate.is_file():
        return candidate
    raise typer.BadParameter(
        f"No OSM extract for '{city}' at {candidate}. Fetch it first: mamut-tools osm fetch-city '{city}' --osm-dir {candidate.parent}"
    )


@generate_app.command("single")
def generate_single_cmd(
    city: Annotated[str, typer.Argument(help="City name (matching <workspace>/osmdata/<City>.osm unless --osm-path).")],
    n_customers: Annotated[int, typer.Option("--n", help="Number of customers.")] = 50,
    method: Annotated[str, typer.Option("--method", help="Sampling method: poi_categories, parametric_attach, hybrid.")] = "poi_categories",
    seed: Annotated[int, typer.Option("--seed")] = 0,
    demand_type: Annotated[int, typer.Option("--demand-type", min=1, max=7)] = 7,
    avg_route_size: Annotated[int, typer.Option("--avg-route-size", min=1, max=7)] = 4,
    depot_mode: Annotated[str, typer.Option("--depot-mode", help="random, center, corner.")] = "center",
    customer_mode: Annotated[str, typer.Option("--customer-mode", help="random, clustered, random_clustered.")] = "random_clustered",
    vrptw: Annotated[bool, typer.Option("--vrptw/--no-vrptw", help="Also derive the fastest-metric VRPTW twin.")] = False,
    tw_method: Annotated[str, typer.Option("--tw-method", help="route_centered or reachable_interval.")] = "route_centered",
    osm_path: Annotated[Optional[Path], typer.Option("--osm-path", help="Explicit OSM extract path.")] = None,
    output_dir: Annotated[Optional[Path], typer.Option("--output-dir", help="Workspace directory (default: the resolved workspace).")] = None,
    replace_existing: Annotated[
        bool,
        typer.Option(
            "--replace/--no-replace",
            help="When an instance of the same name but different content exists: replace it, deleting "
            "its derived twins and BKS (--replace), or keep it and write <name>-2 (default).",
        ),
    ] = False,
) -> None:
    """Generate one instance (3 metric .vrp files + meta + manifest + .vrp.json).

    The result's "action" is created, unchanged (identical content already there,
    nothing written), renamed or replaced.
    """
    from mamut_routing_tools.generation.single import GenerationRequest, generate_single_instance
    from mamut_routing_tools.generation.vrptw import derive_vrptw_from_cvrp
    from mamut_routing_tools.generation.writers import slugify
    from mamut_routing_tools.workspace import instances_dir, resolve_workspace

    workspace = resolve_workspace(output_dir)
    request = GenerationRequest(
        city=city,
        osm_path=_resolve_city_osm(city, osm_path, workspace),
        method=method,
        n_customers=n_customers,
        seed=seed,
        demand_type=demand_type,
        avg_route_size=avg_route_size,
        depot_mode=depot_mode,
        customer_mode=customer_mode,
    )
    result = generate_single_instance(
        request, instances_dir(workspace), on_existing="replace" if replace_existing else "rename"
    )
    if vrptw:
        result["vrptw"] = derive_vrptw_from_cvrp(
            result["folder"],
            result["base_name"],
            tw_method=tw_method,
            place_slug=slugify(city),
            source_seed=seed,
        )
    typer.echo(json.dumps(result, indent=1))


@generate_app.command("preview")
def generate_preview_cmd(
    city: Annotated[str, typer.Argument(help="City name.")],
    n_customers: Annotated[int, typer.Option("--n")] = 50,
    method: Annotated[str, typer.Option("--method")] = "poi_categories",
    seed: Annotated[int, typer.Option("--seed")] = 0,
    depot_mode: Annotated[str, typer.Option("--depot-mode")] = "center",
    customer_mode: Annotated[str, typer.Option("--customer-mode")] = "random_clustered",
    osm_path: Annotated[Optional[Path], typer.Option("--osm-path")] = None,
    output_dir: Annotated[Optional[Path], typer.Option("--output-dir")] = None,
) -> None:
    """Preview a selection as GeoJSON (no artifacts written)."""
    from mamut_routing_tools.generation.single import GenerationRequest, build_generation_selection, preview_geojson
    from mamut_routing_tools.workspace import resolve_workspace

    workspace = resolve_workspace(output_dir)
    request = GenerationRequest(
        city=city,
        osm_path=_resolve_city_osm(city, osm_path, workspace),
        method=method,
        n_customers=n_customers,
        seed=seed,
        depot_mode=depot_mode,
        customer_mode=customer_mode,
    )
    typer.echo(json.dumps(preview_geojson(build_generation_selection(request)), indent=1))


# NB: bulk (batch over cities x sizes x ...) is intentionally not a CLI command.
# The tool CLI is per-instance (single -> derive-vrptw -> derive-td); batch
# family generation is delegated to per-campaign scripts calling the tool as a
# library. generation.bulk.generate_bulk_instances remains available for those
# scripts and for the GUI.

gui_app = typer.Typer(help="Local workbench GUI (loopback server owned by the CLI).", no_args_is_help=True)
app.add_typer(gui_app, name="gui")


@gui_app.command("start")
def gui_start_cmd(
    port: Annotated[int, typer.Option("--port", help="Port to bind (0 = pick a free one).")] = 0,
    output_dir: Annotated[Optional[Path], typer.Option("--output-dir", help="Workspace directory.")] = None,
    open_browser: Annotated[bool, typer.Option("--open/--no-open", help="Open the tokened URL in the default browser.")] = True,
) -> None:
    """Start the workbench GUI server as a managed background process."""
    from mamut_routing_tools.gui import runtime
    from mamut_routing_tools.workspace import resolve_workspace

    workspace = resolve_workspace(output_dir)
    state = runtime.start(workspace, port=port)
    if state.get("already_running"):
        typer.echo(f"Already running (pid {state['pid']}): {state['url']}")
        return
    typer.echo(f"Workbench GUI running (pid {state['pid']}), workspace {workspace}")
    typer.echo(state["url"])
    if open_browser:
        import webbrowser

        webbrowser.open(state["url"])


@gui_app.command("stop")
def gui_stop_cmd(
    output_dir: Annotated[Optional[Path], typer.Option("--output-dir")] = None,
) -> None:
    """Stop the workbench GUI server."""
    from mamut_routing_tools.gui import runtime
    from mamut_routing_tools.workspace import resolve_workspace

    typer.echo(json.dumps(runtime.stop(resolve_workspace(output_dir))))


@gui_app.command("status")
def gui_status_cmd(
    output_dir: Annotated[Optional[Path], typer.Option("--output-dir")] = None,
) -> None:
    """Show the GUI server status."""
    from mamut_routing_tools.gui import runtime
    from mamut_routing_tools.workspace import resolve_workspace

    typer.echo(json.dumps(runtime.status(resolve_workspace(output_dir)), indent=1))


@gui_app.command("run")
def gui_run_cmd(
    port: Annotated[int, typer.Option("--port")] = 8788,
    output_dir: Annotated[Optional[Path], typer.Option("--output-dir")] = None,
) -> None:
    """Run the GUI server in the foreground (development mode)."""
    import secrets

    import uvicorn

    from mamut_routing_tools.gui.server import create_app
    from mamut_routing_tools.workspace import resolve_workspace

    workspace = resolve_workspace(output_dir)
    token = secrets.token_urlsafe(24)
    typer.echo(f"http://127.0.0.1:{port}/?token={token}")
    uvicorn.run(create_app(workspace, token), host="127.0.0.1", port=port, log_level="info")


SOLVER_HELP = (
    "Solver: pyvrp (CVRP/VRPTW), kayros (TDVRP/TDVRPTW Duration), or an external executable "
    "-- filo2, hgs-cvrp, ails2, lkh3, or one of yours -- from the solvers config. "
    "`mamut-routing solvers list` shows what is available."
)


@app.command("solve")
def solve_cmd(
    instance_path: Annotated[Path, typer.Argument(help="A .vrp.json instance (generated or from a benchmark collection).")],
    time_limit: Annotated[int, typer.Option("--time-limit-s", "--time-limit", min=1, help="Wall-clock budget in seconds.")] = 30,
    seed: Annotated[int, typer.Option("--seed")] = 42,
    objective: Annotated[
        Optional[str],
        typer.Option(
            "--objective",
            help="MonoCost, HierarchicalVehicleCost (VRPTW), Duration (TD). Default: MonoCost, or Duration for TD instances.",
        ),
    ] = None,
    solver: Annotated[str, typer.Option("--solver", help=SOLVER_HELP)] = "pyvrp",
    solvers_config: Annotated[
        Optional[Path],
        typer.Option("--solvers-config", help="Solvers config TOML (default: $MAMUT_ROUTING_SOLVERS_CONFIG, then ~/.config/mamut-routing/solvers.toml)."),
    ] = None,
    keep_artifacts: Annotated[
        Optional[Path],
        typer.Option("--keep-artifacts", help="Keep an external solver's input, output and log in this directory."),
    ] = None,
    update_bks: Annotated[
        bool,
        typer.Option(
            "--save-bks/--no-save-bks",
            "--update-bks/--no-update-bks",
            help="Write a BKS file next to the instance when the solution improves it (needs --authors).",
        ),
    ] = False,
    authors: Annotated[
        Optional[str],
        typer.Option("--authors", envvar="MAMUT_ROUTING_BKS_AUTHORS", help="Who to credit in a written BKS (or $MAMUT_ROUTING_BKS_AUTHORS)."),
    ] = None,
) -> None:
    """Solve an instance with any registered solver and check the result.

    Prints JSON. "cost" is the reference checker's cost of the routes and
    "validation" its verdict; "solver_cost" is the solver's own objective in
    instance units, for information. "status" is the solver's termination
    (KAYROS: finished / converged / time_limit). With --save-bks --authors,
    "bks_update" reports the store's action (created, replaced or
    kept_existing, with "tie" when the stored BKS costs exactly the same).
    The flags are those of `mamut-routing solve` (--time-limit and
    --update-bks still work). The JSON is a solution file `mamut-routing
    check` and `bks submit` read. Exit status 1 when "ok" is false (the
    solver failed or the checker rejected its routes).
    """
    from mamut_routing_lib.enums import ObjectiveFunction
    from mamut_routing_lib.solutions import submit_bks
    from mamut_routing_lib.solvers import (
        InstanceNotSupportedError,
        SolverUnavailableError,
        UnknownSolverError,
        run_solver,
    )
    from mamut_routing_lib.solvers.external.config import SolverConfigError
    from mamut_routing_lib.solvers.external.process import terminate_all

    objective_function = None
    if objective:
        try:
            objective_function = next(
                member for member in ObjectiveFunction if member.value.lower() == objective.strip().lower()
            )
        except StopIteration:
            typer.echo(f"Unknown objective '{objective}'; use one of {', '.join(m.value for m in ObjectiveFunction)}.", err=True)
            raise typer.Exit(code=1) from None
    if update_bks and not (authors and authors.strip()):
        typer.echo("--save-bks needs --authors (who to credit in the BKS), or $MAMUT_ROUTING_BKS_AUTHORS.", err=True)
        raise typer.Exit(code=1)
    workdir = None
    if keep_artifacts is not None:
        workdir = keep_artifacts.resolve() / f"{instance_path.stem}-{solver}-seed{seed}"
    try:
        solved = run_solver(
            solver,
            instance_path,
            time_limit_s=time_limit,
            seed=seed,
            objective_function=objective_function,
            workdir=workdir,
            keep_artifacts=workdir is not None,
            config=solvers_config,
        )
    except (UnknownSolverError, SolverUnavailableError, InstanceNotSupportedError, SolverConfigError) as error:
        typer.echo(f"Error: {error}", err=True)
        raise typer.Exit(code=1) from None
    except KeyboardInterrupt:
        terminate_all()
        typer.echo("Interrupted: the solver was stopped.", err=True)
        raise typer.Exit(code=130) from None

    result = solved.result
    payload: dict = {
        "ok": bool(solved.valid and result.status in ("feasible", "timeout")),
        "solver": result.solver,
        "method": result.method,
        "objective_function": solved.objective.value,
        "cost": solved.cost,
        "solver_cost": result.solver_cost,
        "validation": solved.validation_status,
        "status": result.metadata.get("status") or result.status,
        "routes": result.routes,
        "n_routes": len(result.routes),
        "wall_time": round(result.wall_time, 2),
        "metadata": result.metadata,
        "provenance": result.provenance,
    }
    if result.error:
        payload["error"] = result.error
    if solved.support_warnings:
        payload["warnings"] = list(solved.support_warnings)
    evaluations = getattr(solved.check, "route_evaluations", None)
    if evaluations:
        payload["iterations"] = result.metadata.get("iterations")
        payload["route_durations"] = [evaluation.duration for evaluation in evaluations]
    if update_bks:
        if solved.valid:
            update = submit_bks(
                instance_path,
                result.routes,
                authors=str(authors),
                objective_function=solved.objective,
                metadata=solved.bks_metadata(),
                checkable=solved.checkable,
            )
            payload["bks_update"] = {
                "action": update.action,
                "tie": update.tie,
                "path": str(update.path),
                "candidate_cost": update.candidate_cost,
            }
        else:
            payload["bks_update"] = {"action": "skipped", "reason": "no feasible, checker-valid solution"}
    typer.echo(json.dumps(payload, indent=1, default=str))
    if not payload["ok"]:
        raise typer.Exit(code=1)  # scripts must see a failed or invalid solve (the JSON says why)


@generate_app.command("materialize-distances")
def generate_materialize_distances_cmd(
    instances: Annotated[
        list[Path],
        typer.Argument(
            help=(
                "One or more published .vrp.json files, or directories to search "
                "recursively for them."
            )
        ),
    ],
    collection_root: Annotated[
        Path | None,
        typer.Option(
            "--collection-root",
            help="Collection root; found from the marker file above the instance when omitted.",
        ),
    ] = None,
    force: Annotated[
        bool, typer.Option("--force/--no-force", help="Rebuild sidecars that are already present.")
    ] = False,
) -> None:
    """Rebuild the distance sidecars a large instance ships as pins rather than bytes.

    Instances above the size where a distance matrix is worth storing publish
    the road graph and the matrix's sha256, not the matrix. This recomputes
    them from the committed road sidecar and refuses to write anything whose
    digest does not match the pin, so what lands on disk is byte-for-byte what
    the instance was published against.
    """
    from mamut_routing_tools.family import materialize_distances

    targets: list[Path] = []
    for entry in instances:
        if entry.is_dir():
            targets.extend(sorted(entry.rglob("*.vrp.json")))
        else:
            targets.append(entry)
    if not targets:
        raise typer.BadParameter("no .vrp.json files found")

    results = []
    for target in targets:
        record = materialize_distances(target, collection_root=collection_root, force=force)
        record["path"] = str(record["path"]) if record.get("path") else None
        results.append(record)

    counts: dict[str, int] = {}
    for record in results:
        counts[record["status"]] = counts.get(record["status"], 0) + 1
    typer.echo(json.dumps({"instances": len(results), "status": counts, "results": results}, indent=1))


@generate_app.command("derive-vrptw")
def generate_derive_vrptw_cmd(
    folder: Annotated[Path, typer.Argument(help="Folder holding the generated CVRP base files.")],
    base: Annotated[str, typer.Argument(help="Instance base name (e.g. lyon_poi-n51-k5).")],
    tw_method: Annotated[str, typer.Option("--tw-method")] = "route_centered",
    seed: Annotated[int, typer.Option("--seed")] = 0,
) -> None:
    """Derive the fastest-metric VRPTW twin of an already generated CVRP base."""
    from mamut_routing_tools.generation.vrptw import derive_vrptw_from_cvrp

    result = derive_vrptw_from_cvrp(folder, base, tw_method=tw_method, source_seed=seed)
    typer.echo(json.dumps(result, indent=1))


@generate_app.command("derive-td")
def generate_derive_td_cmd(
    folder: Annotated[Path, typer.Argument(help="Folder holding the generated instance files (meta + cvrptw + vrptw manifest).")],
    base: Annotated[str, typer.Argument(help="Instance base name (e.g. nantes_par-n9-k2).")],
    model: Annotated[str, typer.Option("--model", help="Traffic model: bpr or wave.")] = "bpr",
    intensity: Annotated[str, typer.Option("--intensity", help="Traffic intensity: light, moderate, or heavy.")] = "moderate",
    all_combos: Annotated[bool, typer.Option("--all", "--all-combos", help="Derive all model x intensity combinations (6 twins each).")] = False,
    seed: Annotated[int, typer.Option("--seed")] = 42,
    force: Annotated[bool, typer.Option("--force/--no-force", help="Overwrite existing twins/sidecars.")] = False,
) -> None:
    """Derive the TDVRP + TDVRPTW twins of a generated instance (traffic -> ATFs -> TW lift).

    Exits 1 with the reason when the twins cannot be certified (nothing is
    written then). Existing twins are kept only if they were derived from the
    current inputs with the same --seed; --force re-derives regardless.
    """
    from mamut_routing_tools.generation.td import TDDerivationError, derive_td_from_vrptw

    try:
        result = derive_td_from_vrptw(
            folder,
            base,
            model=model,
            intensity=intensity,
            all_combos=all_combos,
            seed=seed,
            force=force,
        )
    except (TDDerivationError, FileNotFoundError) as error:
        typer.echo(f"Error: {error}", err=True)
        raise typer.Exit(code=1) from error
    typer.echo(json.dumps(result, indent=1))


@osm_app.command("fetch-city")
def osm_fetch_city_cmd(
    city: Annotated[str, typer.Argument(help="City or locality name to geocode and download.")],
    country: Annotated[str, typer.Option("--country", help="Optional country to disambiguate the geocode.")] = "",
    osm_dir: Annotated[Path, typer.Option("--osm-dir", help="Directory for the downloaded <city>.osm extract.")] = Path("osmdata"),
    padding_km: Annotated[float, typer.Option("--padding-km", help="Extra bbox padding in km.")] = 0.0,
    max_radius_km: Annotated[float, typer.Option("--max-radius-km", help="Clamp the administrative bbox to a square of this radius around the place's geocode point (0 = no clamp).")] = 0.0,
    profile: Annotated[str, typer.Option("--profile", help="Data profile: generation, road_cache, or full.")] = "generation",
    poi_category: Annotated[Optional[list[str]], typer.Option("--poi-category", help="POI amenity category to include (repeatable; generation profile only).")] = None,
    tile_cache_dir: Annotated[Optional[Path], typer.Option("--tile-cache-dir", help="Persistent validated Overpass tile cache (default: <osm-dir>/.mamut-osm-tile-cache).")] = None,
    tile_cache: Annotated[bool, typer.Option("--tile-cache/--no-tile-cache", help="Reuse successful tiles across interrupted or repeated downloads.")] = True,
) -> None:
    """Download a filtered, road-graph-compatible OSM extract for a city."""
    from mamut_routing_tools.osm import fetch_and_store_city_osm

    def report_progress(event: dict) -> None:
        cached = event.get("cache_hits", 0)
        typer.echo(
            f"[osm fetch] {event['phase']} tiles "
            f"{event['current']}/{event['total']} "
            f"(ok={event['tiles_ok']}, cached={cached})",
            err=True,
        )

    summary = fetch_and_store_city_osm(
        city,
        country=country,
        osm_dir=osm_dir,
        padding_km=padding_km,
        max_radius_km=max_radius_km,
        profile=profile,
        poi_categories=poi_category,
        progress=report_progress,
        tile_cache_dir=tile_cache_dir,
        use_tile_cache=tile_cache,
    )
    typer.echo(json.dumps(summary, indent=1))


@osm_app.command("refresh-pois")
def osm_refresh_pois_cmd(
    cities: Annotated[Optional[list[str]], typer.Argument(help="Cities to refresh (default: every extract in --osm-dir).")] = None,
    osm_dir: Annotated[Optional[Path], typer.Option("--osm-dir", help="Directory holding the <city>.osm extracts (default: the workbench workspace osmdata/).")] = None,
    output_dir: Annotated[Optional[Path], typer.Option("--output-dir", help="Workspace directory, when --osm-dir is not given.")] = None,
    check: Annotated[bool, typer.Option("--check", help="Report coverage and exit without downloading anything.")] = False,
    all_extracts: Annotated[bool, typer.Option("--all", help="Refresh every extract, not only those missing way-mapped POIs.")] = False,
    poi_category: Annotated[Optional[list[str]], typer.Option("--poi-category", help="Amenity category to backfill (repeatable; default: the full catalog).")] = None,
    tile_cache: Annotated[bool, typer.Option("--tile-cache/--no-tile-cache", help="Reuse successful tiles across interrupted or repeated runs.")] = True,
) -> None:
    """Backfill amenities mapped as ways and relations into existing extracts.

    Extracts fetched before ways and relations were queried hold only the POIs
    mapped as nodes -- roughly two thirds of a real city's amenities -- and
    nothing invalidates them, so generation keeps drawing from the smaller pool.
    Only the amenity query is re-run: the road network in each file is left
    alone, so this is far cheaper than re-fetching the cities.
    """
    from mamut_routing_tools.generation.pois import POI_CATEGORIES
    from mamut_routing_tools.osm import audit_extracts, refresh_extracts
    from mamut_routing_tools.workspace import osmdata_dir, resolve_workspace

    root = Path(osm_dir) if osm_dir is not None else osmdata_dir(resolve_workspace(output_dir))
    reports = audit_extracts(root)
    if not reports:
        typer.echo(f"No .osm extract found under {root}", err=True)
        raise typer.Exit(code=1)

    wanted = {value.strip().lower() for value in (cities or []) if value.strip()}
    if wanted:
        reports = [entry for entry in reports if entry["city"].lower() in wanted]
        missing = wanted - {entry["city"].lower() for entry in reports}
        if missing:
            typer.echo(f"No extract for: {', '.join(sorted(missing))}", err=True)
            raise typer.Exit(code=1)

    for entry in reports:
        typer.echo(
            f"{entry['city']:<24} {entry.get('status', '?'):<13} "
            f"{entry.get('poi_total', 0):>6} POIs "
            f"({entry.get('poi_nodes', 0)} nodes / {entry.get('poi_ways', 0)} ways "
            f"/ {entry.get('poi_relations', 0)} relations)",
            err=True,
        )

    stale = [
        entry for entry in reports
        if entry.get("can_refresh") and (all_extracts or entry.get("status") != "complete")
    ]
    if check:
        typer.echo(json.dumps({"osm_dir": str(root), "extracts": reports}, indent=1))
        raise typer.Exit()
    if not stale:
        typer.echo("Every extract already holds way-mapped POIs; nothing to do.", err=True)
        typer.echo(json.dumps({"osm_dir": str(root), "refreshed": 0, "results": []}, indent=1))
        raise typer.Exit()

    def on_city(index: int, total: int, path: Path) -> None:
        typer.echo(f"[osm refresh-pois] {index + 1}/{total} {path.stem}", err=True)

    def report_progress(event: dict) -> None:
        typer.echo(
            f"    {event.get('phase', 'amenities')} tiles "
            f"{event.get('current')}/{event.get('total')} "
            f"(ok={event.get('tiles_ok')}, cached={event.get('cache_hits', 0)})",
            err=True,
        )

    summary = refresh_extracts(
        [Path(entry["path"]) for entry in stale],
        poi_categories=tuple(poi_category) if poi_category else tuple(POI_CATEGORIES),
        on_city=on_city,
        progress=report_progress,
        use_tile_cache=tile_cache,
    )
    summary["osm_dir"] = str(root)
    typer.echo(json.dumps(summary, indent=1))


@osm_app.command("validate")
def osm_validate_cmd(
    osm_path: Annotated[
        Path, typer.Argument(help="OSM XML extract to validate.")
    ],
) -> None:
    """Reject incomplete or Overpass-error extracts before graph construction."""
    from mamut_routing_tools.osm import validate_osm_extract

    typer.echo(json.dumps(validate_osm_extract(osm_path), indent=1))


@roadgraph_app.command("info")
def roadgraph_info_cmd(
    osm_path: Annotated[Path, typer.Argument(help="OSM XML extract to build the road graph from.")],
    only_intersections: Annotated[bool, typer.Option("--only-intersections/--all-nodes")] = True,
    trim_to_connected: Annotated[bool, typer.Option("--trim/--no-trim")] = True,
) -> None:
    """Build the road graph and print vertex/edge statistics."""
    from mamut_routing_tools.roadgraph import load_road_graph

    graph = load_road_graph(
        osm_path,
        only_intersections=only_intersections,
        trim_to_connected=trim_to_connected,
    )
    class_counts: dict[int, int] = {}
    for cls in graph.edge_class:
        class_counts[cls] = class_counts.get(cls, 0) + 1
    typer.echo(
        json.dumps(
            {
                "osm_path": str(graph.osm_path),
                "only_intersections": graph.only_intersections,
                "trim_to_connected": graph.trim_to_connected,
                "vertices": graph.vertex_count,
                "edges": graph.edge_count,
                "total_edge_length_km": round(sum(graph.edge_weight) / 1000.0, 3),
                "edge_class_counts": {str(k): class_counts[k] for k in sorted(class_counts)},
                "ref_lla": {"lat": graph.ref_lla.lat, "lon": graph.ref_lla.lon},
            },
            indent=1,
        )
    )


@geometry_app.command("materialize-plan")
def geometry_materialize_plan_cmd(
    plan_path: Annotated[Path, typer.Argument(help="Group plan JSON (route_geometry.py contract).")],
    repo_root: Annotated[Path, typer.Option("--repo-root", help="MAMUT-routing repo root the plan paths are relative to.")],
    result_dir: Annotated[Optional[Path], typer.Option("--result-dir", help="Directory for per-group result files. Prints to stdout when omitted.")] = None,
) -> None:
    """Materialize a route-geometry group plan (website build contract)."""
    from mamut_routing_tools.geometry import materialize_plan

    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    results = materialize_plan(repo_root, plan)
    if result_dir is None:
        typer.echo(json.dumps(results, sort_keys=True))
        return
    result_dir.mkdir(parents=True, exist_ok=True)
    for result_file, payload in results.items():
        target = result_dir / result_file
        target.write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")), encoding="utf-8")
        typer.echo(str(target))


@convert_app.command("blauth2024")
def convert_blauth2024_cmd(
    upstream: Annotated[Path, typer.Argument(help="Checkout of gitlab.com/muelleratorunibonnde/vrptdt-benchmark (holds instances/).")],
    output_dir: Annotated[Path, typer.Option("--output-dir", help="Family collection root to write into (benchmarks/Blauth2024 or a preview dir): instances go to TDVRPTW/n=<N>/, sidecars to sidecars/n=<N>/.")],
    sizes: Annotated[str, typer.Option("--sizes", help="Comma-separated sizes to convert.")] = "10,500",
    cities: Annotated[str, typer.Option("--cities", help="Comma-separated upstream city names, or 'all'.")] = "all",
    upstream_commit: Annotated[Optional[str], typer.Option("--upstream-commit", help="Upstream git commit recorded in provenance (default: read from the checkout).")] = None,
    verify: Annotated[bool, typer.Option("--verify/--no-verify", help="Re-load every emitted instance and re-check the atf_sha256 pin.")] = True,
) -> None:
    """Convert the Blauth et al. 2024 delivery-only instances into the canonical Blauth2024 family."""
    import subprocess

    from mamut_routing_tools.conversion.blauth2024 import UPSTREAM_CITIES, UPSTREAM_SIZES, convert_family

    size_list = tuple(int(part) for part in sizes.split(","))
    unknown_sizes = set(size_list) - set(UPSTREAM_SIZES)
    if unknown_sizes:
        raise typer.BadParameter(f"unknown sizes {sorted(unknown_sizes)}; upstream has {UPSTREAM_SIZES}")
    city_list = UPSTREAM_CITIES if cities == "all" else tuple(cities.split(","))
    unknown_cities = set(city_list) - set(UPSTREAM_CITIES)
    if unknown_cities:
        raise typer.BadParameter(f"unknown cities {sorted(unknown_cities)}; upstream has {UPSTREAM_CITIES}")
    if upstream_commit is None:
        probe = subprocess.run(
            ["git", "-C", str(upstream), "rev-parse", "HEAD"], capture_output=True, text=True
        )
        upstream_commit = probe.stdout.strip() if probe.returncode == 0 else None

    results = convert_family(
        upstream,
        output_dir,
        cities=city_list,
        sizes=size_list,
        upstream_commit=upstream_commit,
        verify_roundtrip=verify,
    )
    typer.echo(
        json.dumps(
            [
                {
                    "instance": item.instance_name,
                    "n": item.n,
                    "vrp_json": str(item.instance_path),
                    "atf_sha256": item.atf_sha256,
                    "max_arc_arrival": item.max_arrival,
                }
                for item in results
            ],
            indent=1,
        )
    )




# --------------------------------------------------------------------------- #
# BKS campaigns
# --------------------------------------------------------------------------- #

_SPEC_ARG = typer.Argument(help="Campaign spec (TOML); see `mamut_routing_tools.bks_campaign.spec`.")
_ONLY_OPT = typer.Option("--only", help="Regex on instance ids/names (smoke tests, partial runs).")


def _load_campaign(spec_path: Path):  # type: ignore[no-untyped-def]
    from mamut_routing_tools.bks_campaign import load_spec

    try:
        return load_spec(spec_path)
    except (OSError, ValueError) as error:
        typer.echo(f"Error: {spec_path}: {error}", err=True)
        raise typer.Exit(code=2) from error


def _campaign_plan(spec, spec_path: Path, *, only: str | None, retry_failed: bool = False):  # type: ignore[no-untyped-def]
    """``build_plan`` with spec mistakes it can only see now (unknown solver, bad --only) as usage errors."""
    import re

    from mamut_routing_tools.bks_campaign import build_plan

    if only is not None:
        try:
            re.compile(only)
        except re.error as error:
            raise typer.BadParameter(f"not a regular expression ({error})", param_hint="--only") from error
    try:
        return build_plan(spec, only=only, retry_failed=retry_failed)
    except ValueError as error:  # UnknownSolverError, SolverConfigError, a warm start the solver refuses
        typer.echo(f"Error: {spec_path}: {error}", err=True)
        raise typer.Exit(code=2) from error


@bks_campaign_app.command("plan")
def bks_campaign_plan(
    spec_path: Annotated[Path, _SPEC_ARG],
    only: Annotated[Optional[str], _ONLY_OPT] = None,
    retry_failed: Annotated[bool, typer.Option("--retry-failed", help="Count failed / timed-out runs as to do.")] = False,
    as_json: Annotated[bool, typer.Option("--json")] = False,
) -> None:
    """Dry run: what `run` would do -- runs to do and done, core-hours, makespan, memory, refusals."""
    spec = _load_campaign(spec_path)
    plan = _campaign_plan(spec, spec_path, only=only, retry_failed=retry_failed)
    summary = plan.summary(spec.resources.workers)
    summary["unsupported_examples"] = [list(item) for item in plan.unsupported[:10]]
    if as_json:
        typer.echo(json.dumps(summary, indent=1))
        return
    typer.echo(f"campaign {spec.campaign.name} -> {spec.out}")
    typer.echo(f"to do {summary['todo']} ({', '.join(f'{k} {v}' for k, v in summary['per_kind'].items()) or 'nothing'}), done {summary['done']}")
    typer.echo(f"core-hours {summary['core_hours']}, makespan >= {summary['makespan_lower_bound_h']} h on {spec.resources.workers} workers, worst-case memory {summary['worst_case_memory_gb']} GB")
    for solver, reason in plan.unavailable.items():
        typer.secho(f"unavailable: {solver}: {reason}", fg=typer.colors.YELLOW, err=True)
    for instance_id, solver, reason in plan.unsupported[:10]:
        typer.secho(f"unsupported: {instance_id} / {solver}: {reason}", fg=typer.colors.YELLOW, err=True)
    if len(plan.unsupported) > 10:
        typer.secho(f"... and {len(plan.unsupported) - 10} more unsupported pairs", fg=typer.colors.YELLOW, err=True)


@bks_campaign_app.command("baseline")
def bks_campaign_baseline(
    spec_path: Annotated[Path, _SPEC_ARG],
    force: Annotated[bool, typer.Option("--force", help="Replace an existing baseline.")] = False,
) -> None:
    """Freeze the stored BKS of the selected instances (baseline.csv) before the campaign runs."""
    from mamut_routing_tools.bks_campaign import write_baseline

    spec = _load_campaign(spec_path)
    try:
        path = write_baseline(spec, force=force)
    except FileExistsError as error:
        typer.echo(f"Error: {error}", err=True)
        raise typer.Exit(code=1) from error
    typer.echo(f"baseline written: {path}")


@bks_campaign_app.command("run")
def bks_campaign_run(
    spec_path: Annotated[Path, _SPEC_ARG],
    only: Annotated[Optional[str], _ONLY_OPT] = None,
    workers: Annotated[Optional[int], typer.Option("--workers", min=1, help="Override resources.workers.")] = None,
    memory_gb: Annotated[Optional[float], typer.Option("--memory-gb", help="Override resources.memory_gb.")] = None,
    retry_failed: Annotated[bool, typer.Option("--retry-failed", help="Re-run failed / timed-out runs.")] = False,
    max_tasks: Annotated[Optional[int], typer.Option("--max-tasks", min=1, help="Stop after starting this many runs.")] = None,
) -> None:
    """Run the campaign's remaining runs (resumable). Workers never write BKS; `harvest` does.

    First Ctrl-C: no new run starts and the running ones finish. Second: abort
    (solvers are killed with their process groups). Interrupted runs leave no
    record and are picked up by the next `run`. A worker that dies (out of
    memory) gets a failed record (`--retry-failed` runs it again); the
    other runs carry on.
    """
    from mamut_routing_tools.bks_campaign import memory_budget_gb, read_baseline, run_tasks

    spec = _load_campaign(spec_path)
    plan = _campaign_plan(spec, spec_path, only=only, retry_failed=retry_failed)
    for solver, reason in plan.unavailable.items():
        typer.secho(f"unavailable: {solver}: {reason}", fg=typer.colors.YELLOW, err=True)
    if not read_baseline(spec.out):
        typer.secho("Warning: no baseline.csv yet -- run `bks-campaign baseline` first to measure gains.", fg=typer.colors.YELLOW, err=True)
    resolved_workers = workers or spec.resources.workers
    budget = memory_gb if memory_gb is not None else memory_budget_gb(spec.resources.memory_gb)
    typer.echo(f"{len(plan.tasks)} run(s) to do, {len(plan.done)} done; {resolved_workers} workers, {budget:.1f} GB memory budget")
    if not plan.tasks:
        return
    summary = run_tasks(
        plan,
        out=spec.out,
        workers=resolved_workers,
        memory_gb=budget,
        progress=lambda line: typer.echo(line, err=True),
        max_tasks=max_tasks,
    )
    typer.echo(json.dumps(summary, indent=1))
    if summary["aborted"]:
        raise typer.Exit(code=130)


@bks_campaign_app.command("harvest")
def bks_campaign_harvest(
    spec_path: Annotated[Path, _SPEC_ARG],
    offer_all: Annotated[bool, typer.Option("--offer-all", help="Offer every instance's best run, even below the baseline.")] = False,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Report what the store would do without writing.")] = False,
    workers: Annotated[int, typer.Option("--workers", min=1, help="Parallel instances (one process each).")] = 1,
) -> None:
    """Write improved BKS: each instance's best valid run, unless clearly worse than the baseline (the only writer)."""
    from mamut_routing_tools.bks_campaign import harvest

    spec = _load_campaign(spec_path)
    results = harvest(spec, offer_all=offer_all, dry_run=dry_run, workers=workers)
    counts: dict[str, int] = {}
    for item in results:
        counts[item["action"]] = counts.get(item["action"], 0) + 1
    typer.echo(json.dumps({"counts": counts, "results": results}, indent=1, default=str))


@bks_campaign_app.command("report")
def bks_campaign_report(spec_path: Annotated[Path, _SPEC_ARG]) -> None:
    """Write ledger.csv (one row per run) and cross-solver.csv (best per kind, gaps, seed spread)."""
    from mamut_routing_tools.bks_campaign import write_reports

    spec = _load_campaign(spec_path)
    ledger, compare = write_reports(spec)
    typer.echo(f"{ledger}\n{compare}")


@bks_campaign_app.command("status")
def bks_campaign_status(spec_path: Annotated[Path, _SPEC_ARG]) -> None:
    """Runs archived so far, by status, and the last `run` summary."""
    from mamut_routing_tools.bks_campaign import campaign_status

    typer.echo(json.dumps(campaign_status(_load_campaign(spec_path)), indent=1))


if __name__ == "__main__":  # pragma: no cover
    app()
