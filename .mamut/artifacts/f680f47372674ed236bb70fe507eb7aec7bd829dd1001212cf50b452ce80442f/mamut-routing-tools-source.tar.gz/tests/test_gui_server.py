"""GUI server tests: security guards and the workbench endpoint shapes."""

from __future__ import annotations

import io
import json
import time
import zipfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from mamut_routing_tools import osm
from mamut_routing_tools.generation.pois import POI_CATEGORIES
from mamut_routing_tools.gui.server import create_app
from mamut_routing_tools.workspace import jobs_dir, osmdata_dir

TOKEN = "test-token"


@pytest.fixture
def client(tmp_path: Path, fixture_osm_path: Path):  # type: ignore[no-untyped-def]
    workspace = tmp_path / "workspace"
    (osmdata_dir(workspace)).mkdir(parents=True, exist_ok=True)
    (osmdata_dir(workspace) / "Testville.osm").write_text(fixture_osm_path.read_text())
    app = create_app(workspace, TOKEN)
    with TestClient(app, base_url="http://localhost", headers={"X-Mamut-Token": TOKEN}) as test_client:
        yield test_client


def _frontend_source(client: TestClient) -> str:
    """The shell plus the assets it loads, concatenated.

    The frontend used to be one ``index.html`` with inline ``<style>`` and
    ``<script>``; it is now split into ``workbench.css`` / ``workbench.js`` /
    ``layout.js``. These tests care that the frontend exposes a control or label at
    all, not which file carries it, so they assert against the whole bundle.
    """
    parts = [client.get("/").text]
    for asset in ("workbench.css", "workbench.js", "layout.js", "mamut-map.js", "mamut-trips.js"):
        response = client.get(f"/static/{asset}")
        assert response.status_code == 200, f"missing frontend asset {asset}"
        parts.append(response.text)
    return "\n".join(parts)


def _wait_for_job(client: TestClient, job_id: str) -> dict:
    for _ in range(200):
        job = client.get(f"/api/jobs/{job_id}").json()["job"]
        if job["status"] in {"completed", "failed", "cancelled", "interrupted"}:
            return job
        time.sleep(0.02)
    raise AssertionError(f"job {job_id} did not finish")


def test_requests_without_token_or_wrong_host_are_rejected(client: TestClient) -> None:
    assert client.get("/healthz", headers={"X-Mamut-Token": "wrong"}).status_code == 403
    assert client.get("/healthz", headers={"Host": "evil.example"}).status_code == 403
    assert client.get("/healthz").status_code == 200


def test_gui_shell_inlines_the_basemap_api_key_only_when_configured(
    tmp_path: Path, fixture_osm_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    workspace = tmp_path / "workspace"
    (osmdata_dir(workspace)).mkdir(parents=True, exist_ok=True)
    (osmdata_dir(workspace) / "Testville.osm").write_text(fixture_osm_path.read_text())
    app = create_app(workspace, TOKEN)
    headers = {"X-Mamut-Token": TOKEN}

    monkeypatch.delenv("MAMUT_BASEMAP_API_KEY", raising=False)
    with TestClient(app, base_url="http://localhost", headers=headers) as client:
        assert 'window.__MAMUT_BASEMAP_API_KEY__="";' in client.get("/").text

    monkeypatch.setenv("MAMUT_BASEMAP_API_KEY", "cb1_test-KEY_01")
    with TestClient(app, base_url="http://localhost", headers=headers) as client:
        assert 'window.__MAMUT_BASEMAP_API_KEY__="cb1_test-KEY_01";' in client.get("/").text
        # CARTO vector styles through the shared MapLibre kit, every CARTO request
        # keyed; no raster tile template survives (it would draw a watermark).
        source = client.get("/static/workbench.js").text
        kit = client.get("/static/mamut-map.js").text
        assert "apiKey: basemapApiKey," in source
        assert "transformRequest: (url) => withBasemapKey(url, apiKey)" in kit
        assert "https://basemaps.cartocdn.com/gl/${styleName}/style.json?key=" in kit
        assert 'href="https://carto.com/attributions">CARTO</a>' in kit
        assert "{z}/{x}/{y}{r}.png" not in source + kit

    monkeypatch.setenv("MAMUT_BASEMAP_API_KEY", 'bad"key')
    with TestClient(app, base_url="http://localhost", headers=headers) as client:
        with pytest.raises(ValueError, match="MAMUT_BASEMAP_API_KEY"):
            client.get("/")


def test_cities_endpoint_lists_workspace_extracts(client: TestClient) -> None:
    payload = client.get("/api/workbench/generation/cities").json()
    assert payload["ok"] and payload["preview_available"]
    assert [city["slug"] for city in payload["cities"]] == ["testville"]


def test_gui_shell_exposes_restored_generation_and_instance_only_controls(client: TestClient) -> None:
    html = _frontend_source(client)

    assert 'id="depot-mode"' in html
    assert 'id="poi-list"' in html
    assert 'id="hybrid-poi-share"' in html
    assert 'id="customer-mode"' in html
    assert 'id="cluster-seeds"' in html
    assert 'id="cluster-decay"' in html
    assert "POI / ${100 - poiPercent}% parametric" in html
    assert "Excentered (corner)" in html
    assert "Instance only · customer locations" in html
    assert "City fetches store every listed category" in html
    assert "poiCategories: [...POI_CATEGORIES]" in html

    # Bulk configuration overlay with the per-instance table.
    assert 'id="bulk-modal"' in html and 'id="bulk-table-body"' in html
    for control in ("bulk-expand", "bulk-add-row", "bulk-import-csv", "bulk-export-csv", "bulk-check"):
        assert f'id="{control}"' in html
    # Per-row outcome, so a row the city pool could not serve is visible as such.
    assert "<th>Outcome</th>" in html and "bulkOutcomeCell" in html
    # The pre-generation composition line and the dialog that confirms a shortfall.
    assert 'id="gen-notice"' in html
    assert 'id="confirm-modal"' in html and 'id="confirm-ok"' in html
    assert "/api/workbench/generation/preflight" in html
    # POI attachment: the strict rule and the snapping alternative.
    assert 'id="poi-attach-mode"' in html and 'id="poi-attach-radius"' in html
    assert 'value="nearest_vertex"' in html and 'id="help-attach"' in html
    # Stored-extract coverage: check what is on disk, refill what predates ways.
    assert 'id="osm-audit-panel"' in html and 'id="osm-audit-check"' in html
    assert 'id="osm-audit-refresh"' in html
    assert "/api/workbench/osmdata/audit" in html
    # Manual POI picking and the solution import panel.
    assert 'id="manual-options"' in html and 'id="manual-list"' in html
    assert 'value="manual"' in html
    assert 'id="import-panel"' in html and 'id="import-run"' in html
    # Inline help for the dials that used to be bare numbers.
    for help_id in ("help-demand", "help-band", "help-method", "help-depot", "help-metric"):
        assert f'id="{help_id}"' in html
    # The right panel must reflow on narrow screens instead of disappearing.
    assert ".panel-right { display: none; }" not in html
    assert 'id="sheet-toggle"' in html
    # The published workbench appearance controls are available locally too.
    for control in (
        "route-appearance",
        "appearance-render-mode",
        "appearance-depot-opacity",
        "appearance-other-opacity",
        "appearance-customers",
        "appearance-arrows",
        "appearance-depot-star",
    ):
        assert f'id="{control}"' in html
    assert 'value="cached_road"' in html and 'value="straight_line"' in html
    # Route animation: the button, the playback bar host, deck.gl loaded on demand only.
    assert 'id="animate-routes"' in html and 'id="tripsBar"' in html
    assert '<script src="/static/vendor/deck.gl' not in html
    assert 'const DECK_SRC = "/static/vendor/deck.gl/dist.min.js";' in html


def test_gui_shell_groups_the_form_and_moves_jobs_out_of_the_panel(client: TestClient) -> None:
    """The decluttered layout: stepped Generate form, tabbed inspector, bottom strip."""
    html = _frontend_source(client)

    # Generate is four numbered steps with per-step Advanced disclosures.
    assert html.count('class="step-index"') == 4
    assert 'id="adv-place"' in html and 'id="adv-customers"' in html
    # Categories and help moved off the form into popovers over the map.
    assert 'id="poi-popover"' in html and 'id="poi-search"' in html
    assert 'id="help-popover"' in html and 'id="explain-toggle"' in html
    # The 49-checkbox list must still be reachable, just not inline.
    assert 'id="poi-list"' in html

    # The inspector is tabbed rather than a five-section stack.
    for tab in ("tabInstance", "tabSolve", "tabRuns"):
        assert f'id="{tab}"' in html
    for panel in ("instancePanel", "solvePanel", "runsPanel"):
        assert f'id="{panel}"' in html

    # Jobs and the status line are one bottom strip now, not opposite corners.
    assert 'id="activity"' in html and 'id="activity-toggle"' in html
    assert 'id="jobList"' in html and 'id="status"' in html
    assert 'id="jobsSection"' not in html

    # Instance list filters, ported from the published workbench.
    for control in ("inst-search", "inst-city", "inst-sort", "inst-solved"):
        assert f'id="{control}"' in html

    # Resizable panels and their rails.
    assert 'data-splitter="left"' in html and 'data-splitter="right"' in html
    assert 'data-panel-toggle="left"' in html and 'class="panel-rail"' in html


def test_preferences_survive_a_restart_and_reject_unknown_keys(
    tmp_path: Path, fixture_osm_path: Path
) -> None:
    """localStorage is per-origin and the GUI's port changes every start, so the
    theme and layout have to live in the workspace to outlive a restart."""
    workspace = tmp_path / "workspace"
    osmdata_dir(workspace).mkdir(parents=True, exist_ok=True)
    (osmdata_dir(workspace) / "Testville.osm").write_text(fixture_osm_path.read_text())

    with TestClient(
        create_app(workspace, TOKEN), base_url="http://localhost", headers={"X-Mamut-Token": TOKEN}
    ) as first:
        assert first.get("/api/preferences").json() == {}
        stored = first.put(
            "/api/preferences",
            json={
                "theme": "light",
                "layout": {"leftWidth": 480, "rightCollapsed": True},
                "somethingElse": "<script>alert(1)</script>",
            },
        ).json()
        assert stored["theme"] == "light"
        assert stored["layout"]["leftWidth"] == 480
        assert "somethingElse" not in stored

    # A brand-new app on the same workspace stands in for a restart on a new port.
    with TestClient(
        create_app(workspace, TOKEN), base_url="http://localhost", headers={"X-Mamut-Token": TOKEN}
    ) as second:
        assert second.get("/api/preferences").json()["theme"] == "light"
        html = second.get("/").text
        assert "window.__MAMUT_PREFS__=" in html
        assert '"theme": "light"' in html
        # The placeholder must be consumed, never served to the browser as-is.
        assert "<!--MAMUT_PREFS-->" not in html


def test_preferences_clamp_widths_and_ignore_a_corrupt_file(
    tmp_path: Path, fixture_osm_path: Path
) -> None:
    workspace = tmp_path / "workspace"
    osmdata_dir(workspace).mkdir(parents=True, exist_ok=True)
    (osmdata_dir(workspace) / "Testville.osm").write_text(fixture_osm_path.read_text())
    app = create_app(workspace, TOKEN)
    with TestClient(app, base_url="http://localhost", headers={"X-Mamut-Token": TOKEN}) as client:
        clamped = client.put(
            "/api/preferences", json={"layout": {"leftWidth": 5, "rightWidth": 99999}}
        ).json()
        assert clamped["layout"]["leftWidth"] == 240
        assert clamped["layout"]["rightWidth"] == 1200
        assert client.put("/api/preferences", json={"theme": "chartreuse"}).json().get("theme") is None

        (workspace / "state" / "preferences.json").write_text("{not json", encoding="utf-8")
        assert client.get("/api/preferences").json() == {}
        assert client.get("/").status_code == 200


def test_frontend_demand_and_band_labels_match_the_generator(client: TestClient) -> None:
    """The JS tables are a copy of demands.py; keep them honest."""
    from mamut_routing_tools.generation.demands import (
        DEMAND_TYPES,
        avg_route_size_bounds,
        demand_distribution_bounds,
    )

    html = _frontend_source(client)
    for demand_type in DEMAND_TYPES:
        assert f"{{ value: {demand_type}," in html
        low, high = demand_distribution_bounds(demand_type)
        band_low, band_high = avg_route_size_bounds(demand_type)
        # Every bound is quoted somewhere in the help tables (en dash separated).
        assert f"{low}–{high}" in html or demand_type in (1, 6, 7)
        assert f"{int(band_low)}–{int(band_high)}" in html


def test_fetch_job_acquires_the_full_poi_catalog(
    client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    captured: dict = {}

    def fake_fetch(city: str, **kwargs):  # type: ignore[no-untyped-def]
        captured["city"] = city
        captured.update(kwargs)
        return {
            "ok": True,
            "city": city,
            "poi_categories": list(kwargs["poi_categories"]),
        }

    monkeypatch.setattr(osm, "fetch_and_store_city_osm", fake_fetch)
    requested_categories = ["hospital", "library", "charging_station"]
    submitted = client.post(
        "/api/jobs",
        json={
            "kind": "fetch-osm",
            "payload": {"city": "New Poi City", "poiCategories": requested_categories},
        },
    ).json()
    job = _wait_for_job(client, submitted["job"]["job_id"])

    assert job["status"] == "completed", job.get("error")
    assert captured["profile"] == "generation"
    assert captured["poi_categories"] == POI_CATEGORIES
    assert job["result"]["poi_categories"] == POI_CATEGORIES
    assert set(requested_categories) <= set(captured["poi_categories"])


def test_preview_generate_solve_render_round_trip(client: TestClient) -> None:
    body = {
        "city": "Testville",
        "nCustomers": 4,
        "seed": 7,
        "method": "parametric_attach",
        "depotMode": "excentered",
        "customerMode": "clustered",
        "clusterSeeds": 2,
        "clusterDecayMeters": 375,
        "hybridPoiShare": 0.65,
        "categories": ["hospital", "library"],
    }
    preview = client.post("/api/workbench/generation/preview", json=body).json()
    assert preview["ok"] and len(preview["geojson"]["features"]) == 5

    parametric_only_hybrid = client.post(
        "/api/workbench/generation/preview",
        json={
            **body,
            "method": "hybrid",
            "categories": [],
            "hybridPoiShare": 0,
        },
    ).json()
    assert parametric_only_hybrid["ok"]
    assert parametric_only_hybrid["summary"]["poi_customers"] == 0
    assert parametric_only_hybrid["summary"]["parametric_customers"] == 4

    single = client.post("/api/workbench/generation/single", json=body).json()
    assert single["ok"]
    folder = single["folder"]

    listing = client.get("/api/workbench/instances").json()
    assert listing["ok"]
    listed = {entry["base_name"]: entry for entry in listing["instances"]}
    assert single["base_name"] in listed
    entry = listed[single["base_name"]]
    assert entry["folder"] == folder
    assert entry["files"]["vrp_json"]["fastest"] == single["files"]["vrp_json"]["fastest"]
    assert entry["summary"]["capacity"] == single["summary"]["capacity"]
    assert entry["has_vrptw_twin"] is False
    assert entry["solution_count"] == 0

    map_data = client.get(f"/api/instances/{entry['instance_id']}/map-data").json()
    assert map_data["ok"] and len(map_data["geojson"]["features"]) == 5
    assert [feature["properties"]["model_node_id"] for feature in map_data["geojson"]["features"]] == list(range(5))
    assert [feature["properties"]["role"] for feature in map_data["geojson"]["features"]].count("depot") == 1

    vrp_json = client.get(
        "/instances-file", params={"path": f"{folder}/{single['files']['vrp_json']['fastest']}"}
    ).json()
    solved = client.post("/api/workbench/solve", json={"vrp_json": vrp_json, "time_limit": 1}).json()
    assert solved["ok"] and solved["n_routes"] >= 1 and solved["input_source"] == "vrp_json"
    assert sorted(stop for route in solved["routes"] for stop in route) == [1, 2, 3, 4]

    meta = client.get("/instances-file", params={"path": f"{folder}/{single['files']['meta']}"}).json()
    assert meta["generation_params"]["depot_mode"] == "corner"
    assert meta["generation_params"]["customer_mode"] == "clustered"
    assert meta["generation_params"]["cluster_seeds"] == 2
    assert meta["generation_params"]["cluster_decay_meters"] == 375
    assert meta["generation_params"]["hybrid_poi_share"] == 0.65
    assert meta["generation_params"]["categories"] == ["hospital", "library"]
    rendered = client.post(
        "/api/workbench/render-routes", json={"meta": meta, "routes": solved["routes"], "metric": "fastest"}
    ).json()
    assert rendered["ok"] and rendered["summary"]["render_mode"] in ("cached_road", "mixed")
    # One arc start per arc, the first at 0, strictly increasing and inside the line:
    # the client slices per-arc segments (depot legs, animation timing) from them.
    for feature, route in zip(rendered["geojson"]["features"], solved["routes"]):
        starts = feature["properties"]["arc_starts"]
        assert len(starts) == len(route) + 1 and starts[0] == 0
        assert all(later > earlier for earlier, later in zip(starts, starts[1:]))
        assert starts[-1] < len(feature["geometry"]["coordinates"]) - 1

    rendered_euclidean = client.post(
        "/api/workbench/render-routes", json={"meta": meta, "routes": solved["routes"], "metric": "euclidean"}
    ).json()
    drawn_points = {
        tuple(point)
        for feature in rendered_euclidean["geojson"]["features"]
        for point in feature["geometry"]["coordinates"]
    }
    expected_points = {(node["poi_lon"], node["poi_lat"]) for node in meta["nodes"]}
    assert expected_points <= drawn_points

    download = client.post(
        "/api/workbench/generation/single-download",
        json={"folder": folder, "base_name": single["base_name"]},
    )
    assert download.status_code == 200 and download.headers["content-type"] == "application/zip"

    exported = client.post(
        f"/api/workbench/instances/{single['instance_id']}/export-vrp", json={"metric": "fastest"}
    )
    assert exported.status_code == 200, exported.text
    assert exported.headers["content-type"].startswith("text/plain")
    assert exported.headers["content-disposition"] == f'attachment; filename="{single["base_name"]}_fastest.vrp"'
    lines = exported.text.splitlines()
    assert lines[0] == f"NAME : {single['base_name']}_fastest"
    assert "EDGE_WEIGHT_TYPE : EXPLICIT" in lines and "EDGE_WEIGHT_SECTION" in lines
    assert lines[-1] == "EOF" and "DEPOT_SECTION" in lines
    from mamut_routing_tools.generation.writers import parse_cvrp_vrp

    parsed_path = Path(folder) / "exported_check.vrp"
    parsed_path.write_text(exported.text, encoding="utf-8")
    parsed = parse_cvrp_vrp(parsed_path)
    assert parsed.depot_node_index == 1 and parsed.dimension == len(meta["nodes"])

    euclidean = client.post(
        f"/api/workbench/instances/{single['instance_id']}/export-vrp",
        json={"metric": "euclidean", "edge_weight_type": "EUC_2D"},
    )
    assert euclidean.status_code == 200, euclidean.text
    assert "EDGE_WEIGHT_TYPE : EUC_2D" in euclidean.text and "EDGE_WEIGHT_SECTION" not in euclidean.text

    refused = client.post(
        f"/api/workbench/instances/{single['instance_id']}/export-vrp",
        json={"metric": "fastest", "edge_weight_type": "EUC_2D"},
    )
    assert refused.status_code == 400 and "euclidean" in refused.json()["error"]
    assert client.post(f"/api/workbench/instances/{single['instance_id']}/export-vrp", json={"metric": "nope"}).status_code == 400
    assert client.post("/api/workbench/instances/unknown/export-vrp", json={"metric": "fastest"}).status_code == 404


def test_td_build_derives_tdvrp_and_tdvrptw_twins(client: TestClient) -> None:
    generated = client.post(
        "/api/workbench/generation/single",
        json={
            "city": "Testville",
            "nCustomers": 3,
            "seed": 5,
            "method": "parametric_attach",
            "deriveVrptw": True,
        },
    ).json()
    assert generated["ok"] and generated["instance_id"]

    built = client.post(
        "/api/workbench/generation/td-build",
        json={"instance_id": generated["instance_id"], "model": "wave", "intensity": "moderate"},
    ).json()
    assert built["ok"] is True
    assert built["action"] in ("derived", "kept")
    assert len(built["combos"]) == 1
    combo = built["combos"][0]
    assert combo["model"] == "wave" and combo["intensity"] == "moderate"
    folder = Path(generated["folder"])
    assert (folder / combo["tdvrptw_twin"]).is_file()
    assert (folder / combo["tdvrp_twin"]).is_file()


def test_td_build_rejects_unknown_instance(client: TestClient) -> None:
    assert client.post("/api/workbench/generation/td-build", json={"instance_id": "nope"}).status_code == 404


def test_instances_file_refuses_paths_outside_the_workspace(client: TestClient) -> None:
    assert client.get("/instances-file", params={"path": "/etc/passwd"}).status_code == 404


def test_solve_jobs_persist_validated_runs_and_compare_them(client: TestClient) -> None:
    generated = client.post(
        "/api/workbench/generation/single",
        json={"city": "Testville", "nCustomers": 4, "seed": 7, "method": "parametric_attach"},
    ).json()
    assert generated["ok"] and generated["instance_id"]
    instance_id = generated["instance_id"]

    run_ids = []
    for seed in (11, 12):
        submitted = client.post(
            "/api/jobs",
            json={
                "kind": "solve",
                "payload": {
                    "instance_id": instance_id,
                    "metric": "fastest",
                    "objective_function": "MonoCost",
                    "seed": seed,
                    "time_limit": 1,
                },
            },
        ).json()
        job = _wait_for_job(client, submitted["job"]["job_id"])
        assert job["status"] == "completed", job.get("error")
        assert job["result"]["validation"]["valid"] is True
        assert job["result"]["solution"]["seed"] == seed
        run_ids.append(job["result"]["solution"]["run_id"])

    listing = client.get(f"/api/instances/{instance_id}/solutions").json()
    assert [run["run_id"] for run in listing["runs"]] == list(reversed(run_ids))
    assert all(run["validation"]["status"] == "valid" for run in listing["runs"])
    workspace_listing = client.get("/api/workbench/instances").json()["instances"]
    assert next(entry for entry in workspace_listing if entry["instance_id"] == instance_id)["solution_count"] == 2

    comparison = client.post(
        f"/api/instances/{instance_id}/solutions/compare",
        json={"candidate_run_id": run_ids[1], "reference_run_id": run_ids[0]},
    ).json()["comparison"]
    assert comparison["ordering"] in {"better", "equal", "worse"}
    assert comparison["candidate"]["valid"] and comparison["reference"]["valid"]
    assert "directed_edges_added" in comparison["route_difference"]

    rendered = client.post(
        f"/api/instances/{instance_id}/solutions/{run_ids[1]}/render",
        params={"metric": "fastest"},
    ).json()
    assert rendered["ok"] and rendered["summary"]["route_count"] >= 1

    # The animation timeline is clocked by the fastest arc costs, one entry per stop.
    run = next(run for run in listing["runs"] if run["run_id"] == run_ids[1])
    timeline = client.get(f"/api/instances/{instance_id}/solutions/{run_ids[1]}/timeline").json()
    assert timeline["ok"] and timeline["clock"] == "free_flow_fastest" and timeline["time_unit"] == "s"
    assert [[stop[0] for stop in route["stops"]] for route in timeline["routes"]] == run["routes"]
    for route in timeline["routes"]:
        times = [route["departure"]] + [value for stop in route["stops"] for value in stop[1:]] + [route["return_arrival"]]
        assert times == sorted(times)
    assert client.get(f"/api/instances/{instance_id}/solutions/nope/timeline").status_code == 404

    jobs = client.get("/api/jobs").json()["jobs"]
    assert len([job for job in jobs if job["kind"] == "solve" and job["status"] == "completed"]) == 2
    log = client.get(f"/api/jobs/{jobs[0]['job_id']}/log").json()["log"]
    assert "Job completed" in log

    workspace = Path(client.get("/healthz").json()["workspace"])
    with TestClient(
        create_app(workspace, TOKEN),
        base_url="http://localhost",
        headers={"X-Mamut-Token": TOKEN},
    ) as restarted:
        restarted_runs = restarted.get(f"/api/instances/{instance_id}/solutions").json()["runs"]
        assert {run["run_id"] for run in restarted_runs} == set(run_ids)
        restarted_instance = next(
            entry
            for entry in restarted.get("/api/workbench/instances").json()["instances"]
            if entry["instance_id"] == instance_id
        )
        assert restarted_instance["solution_count"] == 2
        restarted_jobs = restarted.get("/api/jobs").json()["jobs"]
        assert all(job["status"] == "completed" for job in restarted_jobs)


def test_restart_marks_unfinished_jobs_as_interrupted(tmp_path: Path) -> None:
    workspace = tmp_path / "workspace"
    jobs_dir(workspace).mkdir(parents=True, exist_ok=True)
    job_id = "unfinished-job"
    (jobs_dir(workspace) / f"{job_id}.json").write_text(
        json.dumps(
            {
                "job_id": job_id,
                "kind": "solve",
                "status": "running",
                "created_at": "2026-07-21T08:00:00+00:00",
                "started_at": "2026-07-21T08:00:01+00:00",
                "finished_at": None,
                "progress": {"message": "Solving", "current": None, "total": None},
                "cancel_requested": False,
                "request": {},
                "result": None,
                "error": None,
            }
        ),
        encoding="utf-8",
    )

    with TestClient(
        create_app(workspace, TOKEN),
        base_url="http://localhost",
        headers={"X-Mamut-Token": TOKEN},
    ) as restarted:
        job = restarted.get(f"/api/jobs/{job_id}").json()["job"]

    assert job["status"] == "interrupted"
    assert job["finished_at"]
    assert job["error"] == "GUI server stopped before this job finished."


def test_poi_endpoint_serves_named_pois_and_filters_by_category(client: TestClient) -> None:
    everything = client.get("/api/workbench/generation/pois", params={"city": "Testville"}).json()
    assert everything["ok"]
    by_ref = {
        (feature["properties"]["osm_type"], feature["properties"]["osm_id"]): feature["properties"]
        for feature in everything["geojson"]["features"]
    }
    assert by_ref[("node", 1)]["name"] == "Chez Un"
    assert by_ref[("node", 1)]["category"] == "restaurant"
    # A nameless amenity is still offered; the picker labels it itself.
    assert by_ref[("node", 3)]["name"] is None
    assert by_ref[("node", 3)]["category"] == "pharmacy"
    # Amenities mapped as a building outline or a multipolygon are offered too,
    # and are told apart from the node sharing their id.
    assert by_ref[("way", 4)]["name"] == "Le Quatre"
    assert by_ref[("node", 4)]["category"] == "school"
    assert by_ref[("relation", 20)]["category"] == "marketplace"
    assert everything["category_counts"]["cafe"] == 1

    filtered = client.get(
        "/api/workbench/generation/pois", params={"city": "Testville", "categories": "cafe,bar"}
    ).json()
    assert {feature["properties"]["category"] for feature in filtered["geojson"]["features"]} == {
        "cafe",
        "bar",
    }

    unknown = client.get(
        "/api/workbench/generation/pois", params={"city": "Testville", "categories": "not_an_amenity"}
    )
    assert unknown.status_code == 400


def test_manual_generation_uses_the_picked_pois(client: TestClient) -> None:
    body = {
        "city": "Testville",
        "method": "manual",
        "seed": 3,
        "manualPoiIds": [2, 3, 4],
        "manualDepotPoiId": 1,
    }
    preview = client.post("/api/workbench/generation/preview", json=body).json()
    assert preview["ok"]
    features = preview["geojson"]["features"]
    assert [feature["properties"]["role"] for feature in features].count("depot") == 1
    assert [feature["properties"]["poi_name"] for feature in features] == [
        "Chez Un",
        "Café Deux",
        None,
        "École Quatre",
    ]

    generated = client.post("/api/workbench/generation/single", json=body).json()
    assert generated["ok"] and generated["summary"]["customers"] == 3
    map_data = client.get(f"/api/instances/{generated['instance_id']}/map-data").json()
    named = [feature["properties"]["poi_name"] for feature in map_data["geojson"]["features"]]
    assert "École Quatre" in named


def test_manual_generation_accepts_typed_picks_including_ways(client: TestClient) -> None:
    # The picker sends {type, id} pairs, because way 4 and node 4 are different
    # places that a bare id could not tell apart.
    body = {
        "city": "Testville",
        "method": "manual",
        "seed": 3,
        "manualPois": [
            {"type": "way", "id": 4},
            {"type": "relation", "id": 20},
            {"type": "node", "id": 2},
        ],
        "manualDepotPoi": {"type": "node", "id": 1},
    }
    preview = client.post("/api/workbench/generation/preview", json=body).json()
    assert preview["ok"]
    picked = [
        (feature["properties"]["poi_name"], feature["properties"]["poi_osm_type"])
        for feature in preview["geojson"]["features"]
    ]
    assert ("Le Quatre", "way") in picked
    assert ("Marché Vingt", "relation") in picked

    generated = client.post("/api/workbench/generation/single", json=body).json()
    assert generated["ok"] and generated["summary"]["customers"] == 3
    map_data = client.get(f"/api/instances/{generated['instance_id']}/map-data").json()
    types = {
        feature["properties"]["poi_osm_type"]
        for feature in map_data["geojson"]["features"]
        if feature["properties"]["poi_osm_type"]
    }
    assert {"way", "relation"} <= types

    unknown_type = client.post(
        "/api/workbench/generation/preview",
        json={**body, "manualPois": [{"type": "cloud", "id": 4}, {"type": "node", "id": 2}]},
    )
    assert unknown_type.json()["ok"] is False


def test_preflight_warns_before_topping_a_poi_request_up_parametrically(
    client: TestClient,
) -> None:
    body = {
        "city": "Testville",
        "nCustomers": 4,
        "seed": 5,
        "method": "poi_categories",
        "depotMode": "excentered",
        "categories": ["cafe"],
    }
    report = client.post("/api/workbench/generation/preflight", json=body).json()
    assert report["ok"]
    # The map is the preview's job; the pre-generation check is about the numbers.
    assert "geojson" not in report
    composition = report["summary"]["composition"]
    assert composition["poi_customers"] == 1 and composition["parametric_customers"] == 3
    assert composition["poi_pool_attachable"] == 1
    assert "parametric road points" in report["notice"]
    assert "select more POI categories" in report["notice"]

    # A request the categories can serve must not nag.
    served = client.post(
        "/api/workbench/generation/preflight",
        json={**body, "nCustomers": 2, "categories": ["restaurant", "cafe", "school", "bar"]},
    ).json()
    assert served["ok"] and served["notice"] is None
    assert served["summary"]["composition"]["parametric_customers"] == 0

    # The generated instance carries the same verdict, so the job report agrees
    # with what the user confirmed.
    generated = client.post("/api/workbench/generation/single", json=body).json()
    assert generated["ok"]
    assert generated["summary"]["composition"]["parametric_customers"] == 3
    assert "parametric road points" in generated["notice"]


def test_bulk_preflight_reports_sizes_the_pool_cannot_serve(client: TestClient) -> None:
    report = client.post(
        "/api/workbench/generation/bulk-preflight",
        json={
            "city": "Testville",
            "method": "parametric_attach",
            "instances": [
                {"city": "Testville", "nCustomers": 3},
                {"city": "Testville", "nCustomers": 900},
            ],
        },
    ).json()
    assert report["ok"] and report["instances"] == 2
    group = report["groups"][0]
    assert group["skipped_sizes"] == [900] and group["status"] == "partial"


def test_bulk_rows_generate_per_row_instances(client: TestClient) -> None:
    job = client.post(
        "/api/jobs",
        json={
            "kind": "bulk-generate",
            "payload": {
                "city": "Testville",
                "method": "parametric_attach",
                "seed": 0,
                "instances": [
                    {"city": "Testville", "nCustomers": 3, "demandType": 1, "avgRouteSize": 1},
                    {
                        "city": "Testville",
                        "nCustomers": 4,
                        "demandType": 5,
                        "avgRouteSize": 2,
                        "problemType": "vrptw",
                    },
                ],
            },
        },
    ).json()["job"]
    finished = _wait_for_job(client, job["job_id"])
    assert finished["status"] == "completed", finished
    result = finished["result"]
    assert result["generated"] == 2
    assert [bool(entry.get("vrptw")) for entry in result["results"]] == [False, True]
    # Per-row demand type and size really reached the generator.
    assert [entry["summary"]["demand_type"] for entry in result["results"]] == [1, 5]
    assert [entry["summary"]["customers"] for entry in result["results"]] == [3, 4]

    listed = {entry["base_name"] for entry in client.get("/api/workbench/instances").json()["instances"]}
    assert {entry["base_name"] for entry in result["results"]} <= listed


def _generate_for_import(client: TestClient) -> dict:
    body = {"city": "Testville", "nCustomers": 4, "seed": 7, "method": "parametric_attach"}
    return client.post("/api/workbench/generation/single", json=body).json()


def test_importing_an_external_solution_validates_before_storing(client: TestClient) -> None:
    instance = _generate_for_import(client)
    instance_id = instance["instance_id"]

    accepted = client.post(
        f"/api/instances/{instance_id}/solutions/import",
        json={
            "metric": "fastest",
            "text": "Route #1: 1 2\nRoute #2: 3 4\nCost 999\n",
            "filename": "external.sol",
            "label": "some-other-solver",
        },
    ).json()
    assert accepted["ok"], accepted
    run = accepted["solution"]
    assert run["source"] == "imported" and run["metadata"]["metric"] == "fastest"
    assert run["validation"]["valid"] and run["num_routes"] == 2
    # The declared cost was wrong, so the checked value is stored and flagged.
    assert accepted["warning"] and run["cost"] == run["validation"]["routing_cost"]

    runs = client.get(f"/api/instances/{instance_id}/solutions").json()["runs"]
    assert [entry["run_id"] for entry in runs] == [run["run_id"]]


def test_importing_an_lkh3_solution_file_is_accepted(client: TestClient) -> None:
    """LKH-3's MTSP_SOLUTION_FILE: depot node 1, customers 2..n+1, empty vehicles dropped."""
    instance = _generate_for_import(client)
    text = (
        "problem, Cost: 0_1234\nThe tours traveled by the 3 salesmen are:\n"
        "1 2 3 1 (#2)  Cost: 600\n1 4 5 1 (#2)  Cost: 634\n1 1 (#0)  Cost: 0\n"
    )
    response = client.post(
        f"/api/instances/{instance['instance_id']}/solutions/import",
        json={"metric": "fastest", "text": text, "filename": "problem.sol", "label": "LKH-3"},
    ).json()
    assert response["ok"], response
    run = response["solution"]
    assert run["routes"] == [[1, 2], [3, 4]] and run["metadata"]["format"] == "lkh-mtsp"
    assert run["solver"] == "LKH-3"


@pytest.mark.parametrize(
    ("text", "message"),
    [
        ("Route #1: 1 2\nRoute #2: 3 3\n", "more than once"),
        ("Route #1: 1 2\n", "never visited"),
        ("Route #1: 1 2 3 4 77\n", "fits neither"),
        ("nothing useful here\n", "No 'Route #k"),
        ("", "Paste a solution"),
    ],
)
def test_importing_a_broken_solution_is_refused(client: TestClient, text: str, message: str) -> None:
    instance = _generate_for_import(client)
    instance_id = instance["instance_id"]
    response = client.post(
        f"/api/instances/{instance_id}/solutions/import",
        json={"metric": "fastest", "text": text},
    )
    assert response.status_code == 400
    assert message in response.json()["error"]
    # Nothing is stored when the import is refused.
    assert client.get(f"/api/instances/{instance_id}/solutions").json()["runs"] == []


def test_importing_a_zero_based_solution_is_accepted(client: TestClient) -> None:
    """Files numbering customers 0..n-1 must be understood, not rejected as
    incomplete because their customer 0 was mistaken for a depot marker."""
    instance = _generate_for_import(client)
    accepted = client.post(
        f"/api/instances/{instance['instance_id']}/solutions/import",
        json={"metric": "fastest", "text": "Route #1: 0 1\nRoute #2: 2 3\n"},
    ).json()
    assert accepted["ok"], accepted
    # Shifted onto model ids 1..n, every customer visited exactly once.
    assert sorted(stop for route in accepted["solution"]["routes"] for stop in route) == [1, 2, 3, 4]


def test_importing_a_one_based_solution_with_explicit_depots_is_accepted(
    client: TestClient,
) -> None:
    """The other convention: 1..n with 0 written at the route boundaries."""
    instance = _generate_for_import(client)
    accepted = client.post(
        f"/api/instances/{instance['instance_id']}/solutions/import",
        json={"metric": "fastest", "text": "Route #1: 0 1 2 0\nRoute #2: 0 3 4 0\n"},
    ).json()
    assert accepted["ok"], accepted
    assert accepted["solution"]["routes"] == [[1, 2], [3, 4]]


def test_poi_endpoint_caps_how_many_features_it_returns(client: TestClient) -> None:
    """A real extract holds tens of thousands of amenities; the picker must not
    be handed all of them at once."""
    capped = client.get(
        "/api/workbench/generation/pois", params={"city": "Testville", "limit": 2}
    ).json()
    assert capped["returned"] == 2 and capped["truncated"] is True
    assert capped["matching"] > 2
    assert len(capped["geojson"]["features"]) == 2

    full = client.get("/api/workbench/generation/pois", params={"city": "Testville"}).json()
    assert full["truncated"] is False and full["returned"] == full["matching"]


def test_osmdata_audit_flags_extracts_missing_outline_pois(
    client: TestClient, tmp_path: Path
) -> None:
    # A second extract in the shape produced before ways were fetched.
    (osmdata_dir(tmp_path / "workspace") / "Oldtown.osm").write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n<osm version="0.6">\n'
        '  <bounds minlat="44.99" minlon="3.99" maxlat="45.01" maxlon="4.01"/>\n'
        '<node id="1" lat="45.0" lon="4.0"><tag k="amenity" v="cafe"/></node>\n'
        '<way id="10"><nd ref="1"/><tag k="highway" v="residential"/></way>\n'
        "</osm>\n",
        encoding="utf-8",
    )
    report = client.get("/api/workbench/osmdata/audit").json()
    assert report["ok"]
    by_city = {entry["city"]: entry for entry in report["extracts"]}
    assert by_city["Testville"]["status"] == "complete"
    assert by_city["Testville"]["poi_ways"] == 1
    assert by_city["Oldtown"]["status"] == "nodes_only"
    assert report["outdated"] == 1


def test_refresh_pois_job_backfills_the_outdated_extracts(
    client: TestClient, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from mamut_routing_tools.osm import fetch as fetch_module

    (osmdata_dir(tmp_path / "workspace") / "Oldtown.osm").write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n<osm version="0.6">\n'
        '  <bounds minlat="44.99" minlon="3.99" maxlat="45.01" maxlon="4.01"/>\n'
        '<node id="1" lat="45.0" lon="4.0"><tag k="amenity" v="cafe"/></node>\n'
        '<way id="10"><nd ref="1"/><tag k="highway" v="residential"/></way>\n'
        "</osm>\n",
        encoding="utf-8",
    )
    queries: list[str] = []

    def fake_fetch(query: str, **kwargs):  # type: ignore[no-untyped-def]
        queries.append(query)
        return fetch_module.OverpassResult(
            body='<?xml version="1.0"?><osm version="0.6">'
            '<way id="88"><center lat="45.001" lon="4.001"/>'
            '<tag k="amenity" v="restaurant"/><tag k="name" v="Le Contour"/></way></osm>'
        )

    monkeypatch.setattr(fetch_module, "fetch_overpass_body", fake_fetch)
    submitted = client.post(
        "/api/jobs", json={"kind": "refresh-pois", "payload": {}}
    ).json()
    job = _wait_for_job(client, submitted["job"]["job_id"])

    assert job["status"] == "completed", job.get("error")
    result = job["result"]
    # Only the extract that needed it: Testville already holds way-mapped POIs.
    assert [entry["city"] for entry in result["results"]] == ["Oldtown"]
    assert result["refreshed"] == 1 and result["gained"] >= 1
    assert queries and all("highway" not in query for query in queries)

    after = client.get("/api/workbench/osmdata/audit").json()
    assert {entry["status"] for entry in after["extracts"]} == {"complete"}
    assert after["outdated"] == 0
    # The refilled POI is immediately selectable in the picker.
    pois = client.get(
        "/api/workbench/generation/pois", params={"city": "Oldtown", "categories": "restaurant"}
    ).json()
    assert [feature["properties"]["name"] for feature in pois["geojson"]["features"]] == [
        "Le Contour"
    ]


def test_poi_attach_mode_travels_from_the_payload_to_the_instance(client: TestClient) -> None:
    body = {
        "city": "Testville",
        "nCustomers": 3,
        "seed": 5,
        "method": "poi_categories",
        "depotMode": "excentered",
        "categories": ["bank", "cafe", "restaurant"],
    }
    # The bank's nearest road node is not an intersection, so the strict rule
    # cannot serve it and the request is topped up parametrically.
    strict = client.post("/api/workbench/generation/preflight", json=body).json()
    assert strict["summary"]["composition"]["parametric_customers"] == 1
    assert "switch POI attachment to 'nearest vertex'" in strict["notice"]

    snapped = client.post(
        "/api/workbench/generation/preflight",
        json={**body, "poiAttachMode": "nearest_vertex", "poiAttachRadiusM": 400},
    ).json()
    assert snapped["ok"] and snapped["notice"] is None
    assert snapped["summary"]["composition"]["parametric_customers"] == 0

    generated = client.post(
        "/api/workbench/generation/single",
        json={**body, "poiAttachMode": "nearest_vertex", "poiAttachRadiusM": 400},
    ).json()
    assert generated["ok"]
    map_data = client.get(f"/api/instances/{generated['instance_id']}/map-data").json()
    snaps = [feature["properties"]["snap_distance_m"] for feature in map_data["geojson"]["features"]]
    assert any(distance > 300 for distance in snaps), "the moved POI records how far it went"

    rejected = client.post(
        "/api/workbench/generation/preflight", json={**body, "poiAttachMode": "teleport"}
    )
    assert rejected.json()["ok"] is False


def test_running_solve_reports_live_progress_and_a_search_trace(client: TestClient) -> None:
    """A solve used to publish one message and then go silent for its whole budget.

    This pins the whole live-progress feature: while the job runs its progress message must
    keep changing, and it must carry the elapsed-against-budget pair the UI draws its bar
    from. The job log must end up holding the search trace rather than only the request line.
    """
    generated = client.post(
        "/api/workbench/generation/single",
        json={"city": "Testville", "nCustomers": 4, "seed": 7, "method": "parametric_attach"},
    ).json()
    assert generated["ok"]

    budget = 4
    submitted = client.post(
        "/api/jobs",
        json={
            "kind": "solve",
            "payload": {
                "instance_id": generated["instance_id"],
                "metric": "fastest",
                "objective_function": "MonoCost",
                "seed": 3,
                "time_limit": budget,
            },
        },
    ).json()
    job_id = submitted["job"]["job_id"]

    seen: list[dict] = []
    for _ in range(400):
        job = client.get(f"/api/jobs/{job_id}").json()["job"]
        if job["status"] == "running":
            seen.append(job["progress"])
        if job["status"] in {"completed", "failed", "cancelled", "interrupted"}:
            break
        time.sleep(0.02)

    assert job["status"] == "completed", job.get("error")
    messages = [entry["message"] for entry in seen]
    assert len(set(messages)) > 1, f"the solve never reported anything new: {set(messages)}"

    timed = [entry for entry in seen if entry.get("unit") == "s"]
    assert timed, "no progress carried the elapsed/budget pair the progress bar needs"
    assert all(entry["total"] == budget for entry in timed)
    assert all(0 <= entry["current"] <= budget for entry in timed)
    assert any("iters" in entry["message"] for entry in timed)

    log = client.get(f"/api/jobs/{job_id}/log").json()["log"]
    assert "iter" in log, f"the job log holds no search trace: {log!r}"


def test_cancelling_a_running_solve_stops_it_without_recording_a_run(client: TestClient) -> None:
    """Cancel used to be a lie on a running solve: the only checkpoints straddled the
    blocking call, so the job ran its full budget and only then reported 'cancelled'.
    The monitor now carries the request into the search."""
    generated = client.post(
        "/api/workbench/generation/single",
        json={"city": "Testville", "nCustomers": 4, "seed": 7, "method": "parametric_attach"},
    ).json()
    instance_id = generated["instance_id"]
    before = len(client.get(f"/api/instances/{instance_id}/solutions").json()["runs"])

    submitted = client.post(
        "/api/jobs",
        json={
            "kind": "solve",
            "payload": {
                "instance_id": instance_id,
                "metric": "fastest",
                "objective_function": "MonoCost",
                "seed": 5,
                "time_limit": 120,
            },
        },
    ).json()
    job_id = submitted["job"]["job_id"]

    for _ in range(400):
        if client.get(f"/api/jobs/{job_id}").json()["job"]["status"] == "running":
            break
        time.sleep(0.02)

    started = time.monotonic()
    assert client.delete(f"/api/jobs/{job_id}").json()["ok"]
    job = _wait_for_job(client, job_id)

    assert job["status"] == "cancelled", job
    assert time.monotonic() - started < 30, "cancellation waited out the 120 s budget"
    after = client.get(f"/api/instances/{instance_id}/solutions").json()["runs"]
    assert len(after) == before, "a cancelled solve must not persist a truncated run"


def test_gui_shell_exposes_the_classic_vrp_export_controls(client: TestClient) -> None:
    html = _frontend_source(client)
    assert 'id="download-vrp"' in html
    assert 'id="download-vrp-euc2d"' in html
    assert "/export-vrp" in html


def _generate(client: TestClient, **overrides) -> dict:
    body = {"city": "Testville", "nCustomers": 4, "seed": 7, "method": "parametric_attach", "depotMode": "center"}
    body.update(overrides)
    generated = client.post("/api/workbench/generation/single", json=body).json()
    assert generated["ok"], generated
    return generated


def _solve(client: TestClient, instance_id: str) -> str:
    submitted = client.post(
        "/api/jobs",
        json={
            "kind": "solve",
            "payload": {"instance_id": instance_id, "metric": "fastest", "objective_function": "MonoCost", "time_limit": 1},
        },
    ).json()
    job = _wait_for_job(client, submitted["job"]["job_id"])
    assert job["status"] == "completed", job.get("error")
    return job["result"]["solution"]["run_id"]


def _solution_count(client: TestClient, instance_id: str) -> int:
    listing = client.get("/api/workbench/instances").json()["instances"]
    return next(entry for entry in listing if entry["instance_id"] == instance_id)["solution_count"]


def test_regeneration_never_reattaches_old_runs(client: TestClient) -> None:
    """Audit L-tools-gui-01: another seed / depot with the same k overwrote the base in place,
    and the old run showed as valid with its old cost on the new customers."""
    first = _generate(client)
    assert first["action"] == "created"
    run_id = _solve(client, first["instance_id"])
    fastest = Path(first["folder"]) / first["files"]["fastest"]
    original = fastest.read_bytes()

    again = _generate(client)
    assert again["action"] == "unchanged" and again["base_name"] == first["base_name"]
    assert fastest.read_bytes() == original and _solution_count(client, first["instance_id"]) == 1

    other = _generate(client, seed=1, depotMode="corner")
    assert other["action"] == "renamed" and other["base_name"] == f"{first['base_name']}-2"
    assert fastest.read_bytes() == original
    assert _solution_count(client, first["instance_id"]) == 1

    # "Replace existing": the same configuration now takes the original name.
    replaced = _generate(client, seed=1, depotMode="corner", overwrite=True)
    assert replaced["action"] == "replaced" and replaced["base_name"] == first["base_name"]
    assert fastest.read_bytes() != original
    runs = client.get(f"/api/instances/{first['instance_id']}/solutions").json()["runs"]
    assert [run["stale"] for run in runs] == [True]
    assert _solution_count(client, first["instance_id"]) == 0
    rendered = client.post(f"/api/instances/{first['instance_id']}/solutions/{run_id}/render")
    assert rendered.status_code == 409


def test_replacing_an_instance_marks_its_runs_stale(client: TestClient) -> None:
    first = _generate(client)
    run_id = _solve(client, first["instance_id"])
    # Regenerate the same name with other content: rewrite the fastest variant as
    # a replace would, then check the run is flagged, uncounted and refused.
    instance_file = Path(first["folder"]) / first["files"]["vrp_json"]["fastest"]
    payload = json.loads(instance_file.read_text(encoding="utf-8"))
    payload["demands"] = [0] + [demand + 1 for demand in payload["demands"][1:]]
    instance_file.write_text(json.dumps(payload), encoding="utf-8")
    runs = client.get(f"/api/instances/{first['instance_id']}/solutions").json()["runs"]
    assert runs[0]["stale"] is True and "regenerated" in runs[0]["stale_reason"]
    assert _solution_count(client, first["instance_id"]) == 0
    assert client.post(f"/api/instances/{first['instance_id']}/solutions/{run_id}/render").status_code == 409
    assert client.get(f"/api/instances/{first['instance_id']}/solutions/{run_id}/timeline").status_code == 409
    compared = client.post(
        f"/api/instances/{first['instance_id']}/solutions/compare",
        json={"candidate_run_id": run_id, "reference_run_id": run_id},
    )
    assert compared.status_code == 409


def test_downloads_ship_exactly_the_requested_bases(client: TestClient) -> None:
    """Audit L-tools-gui-03: a prefix match zipped sibling bases (k2 took k25 and k2-2)."""
    first = _generate(client)
    folder = Path(first["folder"])
    base = first["base_name"]
    for sibling in (f"{base}5", f"{base}-2"):
        (folder / f"{sibling}_meta.json").write_text("{}", encoding="utf-8")
    response = client.post(
        "/api/workbench/generation/single-download", json={"folder": str(folder), "base_name": base}
    )
    with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
        names = archive.namelist()
    assert names and all(name.startswith(f"{base}_") for name in names)
    assert client.post("/api/workbench/generation/bulk-download", json={"base_names": []}).status_code == 400


def test_legacy_runs_are_rechecked_once_and_cached(client: TestClient) -> None:
    first = _generate(client)
    run_id = _solve(client, first["instance_id"])
    workspace = Path(client.get("/healthz").json()["workspace"])
    run_file = next(workspace.rglob(f"{run_id}.json"))
    record = json.loads(run_file.read_text(encoding="utf-8"))
    record.pop("instance_sha256")
    record["schema_version"] = 1
    run_file.write_text(json.dumps(record), encoding="utf-8")

    runs = client.get(f"/api/instances/{first['instance_id']}/solutions").json()["runs"]
    assert runs[0]["stale"] is False
    assert json.loads(run_file.read_text(encoding="utf-8"))["legacy_check"]["stale"] is False

    instance_file = Path(first["folder"]) / first["files"]["vrp_json"]["fastest"]
    payload = json.loads(instance_file.read_text(encoding="utf-8"))
    payload["vehicle_capacity"] = 1  # the saved routes no longer fit
    instance_file.write_text(json.dumps(payload), encoding="utf-8")
    runs = client.get(f"/api/instances/{first['instance_id']}/solutions").json()["runs"]
    assert runs[0]["stale"] is True


# --------------------------------------------------------------------------- #
# Solver selection: the registry, external solvers, real cancellation
# --------------------------------------------------------------------------- #

_FAKE_CONFIG = """schema_version = 1
[solvers.fake]
label = "Fake LKH"
runtime = "python"
input_format = "lkh"
output_format = "lkh-mtsp"
problem_types = ["CVRP"]
symmetric_only = false
argv = ["{python}", "-m", "mamut_routing_lib.solvers.external._fake_solver", "--params", "{params}"]
progress_pattern = "progress cost=(?P<cost>[0-9.]+)"
"""


@pytest.fixture
def fake_solver_config(tmp_path: Path, monkeypatch) -> Path:
    from mamut_routing_lib.solvers import reload_solvers

    path = tmp_path / "solvers.toml"
    path.write_text(_FAKE_CONFIG)
    monkeypatch.setenv("MAMUT_ROUTING_SOLVERS_CONFIG", str(path))
    reload_solvers()
    return path


def test_solvers_endpoint_lists_availability_and_per_instance_support(client: TestClient, fake_solver_config: Path) -> None:
    listing = client.get("/api/solvers").json()
    assert listing["ok"] and listing["config"] == str(fake_solver_config.resolve())
    by_name = {row["name"]: row for row in listing["solvers"]}
    assert by_name["pyvrp"]["available"] and by_name["fake"]["available"]
    assert {"kayros", "filo2", "hgs-cvrp", "ails2", "lkh3"} <= set(by_name)
    assert "supported" not in by_name["pyvrp"]

    instance_id = _generate(client)["instance_id"]
    scoped = {row["name"]: row for row in client.get(f"/api/solvers?instance_id={instance_id}&metric=fastest").json()["solvers"]}
    assert scoped["pyvrp"]["supported"] and scoped["fake"]["supported"]
    assert not scoped["kayros"]["supported"] and "TDVRP" in scoped["kayros"]["reasons"][0]
    assert not scoped["filo2"]["supported"]  # a road metric: coordinates do not define the costs
    assert client.get("/api/solvers?instance_id=nope").status_code == 404


def test_the_hierarchical_objective_on_cvrp_leaves_solvers_enabled(client: TestClient) -> None:
    # The solve job runs CVRP as MonoCost whatever the objective select says: so does the support check.
    instance_id = _generate(client)["instance_id"]
    query = f"/api/solvers?instance_id={instance_id}&metric=fastest&objective_function=HierarchicalVehicleCost"
    by_name = {row["name"]: row for row in client.get(query).json()["solvers"]}
    assert by_name["pyvrp"]["supported"], by_name["pyvrp"]["reasons"]


def test_a_broken_solvers_config_leaves_pyvrp_usable(client: TestClient, tmp_path: Path, monkeypatch) -> None:
    from mamut_routing_lib.solvers import reload_solvers

    broken = tmp_path / "broken.toml"
    broken.write_text('schema_version = 1\n[solvers.filo2]\nexecutable = "/opt/filo2\n')  # unclosed string
    monkeypatch.setenv("MAMUT_ROUTING_SOLVERS_CONFIG", str(broken))
    reload_solvers()
    instance_id = _generate(client)["instance_id"]
    listing = client.get(f"/api/solvers?instance_id={instance_id}&metric=fastest").json()
    assert listing["ok"] and "solvers config" in listing["config_error"]
    by_name = {row["name"]: row for row in listing["solvers"]}
    assert [row["name"] for row in listing["solvers"]][:2] == ["pyvrp", "kayros"]
    assert by_name["pyvrp"]["available"] and by_name["pyvrp"]["supported"]
    assert not by_name["filo2"]["available"] and "solvers config" in by_name["filo2"]["reason"]
    submitted = client.post("/api/jobs", json={"kind": "solve", "payload": {"instance_id": instance_id, "time_limit": 1}})
    assert submitted.status_code == 200, submitted.json()
    refused = client.post(
        "/api/jobs", json={"kind": "solve", "payload": {"instance_id": instance_id, "time_limit": 1, "solver": "filo2"}}
    )
    assert refused.status_code == 400 and "solvers config" in refused.json()["error"]
    _wait_for_job(client, submitted.json()["job"]["job_id"])


def test_an_external_solve_job_records_the_solver_and_its_provenance(client: TestClient, fake_solver_config: Path) -> None:
    instance_id = _generate(client)["instance_id"]
    submitted = client.post(
        "/api/jobs",
        json={"kind": "solve", "payload": {"instance_id": instance_id, "metric": "fastest", "solver": "fake", "time_limit": 5}},
    ).json()
    job = _wait_for_job(client, submitted["job"]["job_id"])
    assert job["status"] == "completed", job.get("error")
    run = job["result"]["solution"]
    assert run["solver"] == "fake" and run["method"] == "fake"
    assert run["validation"]["valid"]
    assert run["metadata"]["provenance"]["scale"]["exact"] is True
    assert job["result"]["cost"] == pytest.approx(job["result"]["solver_cost"])


def test_an_unknown_or_unavailable_solver_is_refused_at_submission(client: TestClient, monkeypatch) -> None:
    instance_id = _generate(client)["instance_id"]
    unknown = client.post("/api/jobs", json={"kind": "solve", "payload": {"instance_id": instance_id, "solver": "nope"}})
    assert unknown.status_code == 400 and "unknown solver" in unknown.json()["error"]
    monkeypatch.setenv("PATH", "/nonexistent")
    missing = client.post("/api/jobs", json={"kind": "solve", "payload": {"instance_id": instance_id, "solver": "lkh3"}})
    assert missing.status_code == 400 and "not available" in missing.json()["error"]


def test_cancelling_an_external_solve_kills_the_solver(client: TestClient, fake_solver_config: Path, monkeypatch) -> None:
    from mamut_routing_lib.solvers.external.process import live_process_count

    monkeypatch.setenv("FAKE_MODE", "sleep")
    instance_id = _generate(client)["instance_id"]
    before = len(client.get(f"/api/instances/{instance_id}/solutions").json()["runs"])
    submitted = client.post(
        "/api/jobs",
        json={"kind": "solve", "payload": {"instance_id": instance_id, "metric": "fastest", "solver": "fake", "time_limit": 300}},
    ).json()
    job_id = submitted["job"]["job_id"]
    for _ in range(400):
        if live_process_count() > 0:
            break
        time.sleep(0.02)
    assert live_process_count() == 1
    started = time.monotonic()
    client.delete(f"/api/jobs/{job_id}")
    job = _wait_for_job(client, job_id)
    assert job["status"] == "cancelled"
    assert time.monotonic() - started < 10
    assert live_process_count() == 0
    assert len(client.get(f"/api/instances/{instance_id}/solutions").json()["runs"]) == before


def test_the_solve_panel_offers_a_solver_select(client: TestClient) -> None:
    source = _frontend_source(client)
    assert 'id="solve-solver"' in source and 'id="solve-solver-note"' in source
    assert "/api/solvers" in source and "solver," in source  # the job payload carries the solver


def test_an_unsupported_solver_and_variant_pair_is_refused_at_submission(
    client: TestClient, tmp_path: Path, monkeypatch
) -> None:
    from mamut_routing_lib.solvers import reload_solvers

    path = tmp_path / "vrptw-only.toml"
    path.write_text(_FAKE_CONFIG.replace('problem_types = ["CVRP"]', 'problem_types = ["VRPTW"]'))
    monkeypatch.setenv("MAMUT_ROUTING_SOLVERS_CONFIG", str(path))
    reload_solvers()
    instance_id = _generate(client)["instance_id"]
    refused = client.post(
        "/api/jobs",
        json={"kind": "solve", "payload": {"instance_id": instance_id, "metric": "fastest", "solver": "fake", "time_limit": 1}},
    )
    assert refused.status_code == 400 and "cannot solve this variant" in refused.json()["error"]
    assert "not CVRP" in refused.json()["error"]  # refused before a job is queued, not inside it
    accepted = client.post(
        "/api/jobs",
        json={"kind": "solve", "payload": {"instance_id": instance_id, "metric": "fastest", "solver": "pyvrp", "time_limit": 1}},
    )
    assert accepted.status_code == 200, accepted.json()
    _wait_for_job(client, accepted.json()["job"]["job_id"])


def test_one_bad_solver_table_leaves_the_others_listed(client: TestClient, tmp_path: Path, monkeypatch) -> None:
    from mamut_routing_lib.solvers import reload_solvers

    path = tmp_path / "solvers.toml"
    path.write_text(_FAKE_CONFIG + '[solvers.filo2]\nexecutabel = "/opt/filo2"\n')
    monkeypatch.setenv("MAMUT_ROUTING_SOLVERS_CONFIG", str(path))
    reload_solvers()
    listing = client.get("/api/solvers").json()
    by_name = {row["name"]: row for row in listing["solvers"]}
    assert listing["config_error"] is None and by_name["fake"]["available"]
    assert not by_name["filo2"]["available"] and "did you mean 'executable'" in by_name["filo2"]["reason"]


def test_instances_generated_before_the_family_rename_still_open(client: TestClient) -> None:
    # Workbench instances from July 2026 are embedded CVRP files labelled Mamut2026 (now Poryos2026).
    generated = _generate(client)
    instance_id = generated["instance_id"]
    folder = Path(generated["folder"])
    for path in folder.glob("*.vrp.json"):
        payload = json.loads(path.read_text())
        if payload.get("benchmark_name") == "Poryos2026":
            payload["benchmark_name"] = "Mamut2026"
            path.write_text(json.dumps(payload))
    listing = client.get(f"/api/solvers?instance_id={instance_id}&metric=fastest")
    assert listing.status_code == 200, listing.json()
    assert {row["name"]: row for row in listing.json()["solvers"]}["pyvrp"]["supported"]
    assert client.get(f"/api/instances/{instance_id}/solutions").status_code == 200
    run_id = _solve(client, instance_id)
    assert run_id


def test_animate_is_offered_on_the_solve_and_runs_tabs_too(client: TestClient) -> None:
    source = _frontend_source(client)
    for button in ('id="animate-routes"', 'id="solve-animate"', 'id="runs-animate"'):
        assert button in source
    assert source.count("data-animate-routes") >= 4  # three buttons, and the script drives them all
    assert "syncAnimateButton();  // nothing is drawn any more" in source  # Clear map hides them


def _timeline_record(tmp_path: Path, *, time_windows: list | None, fastest: bool = True) -> dict:
    """A workspace record whose fastest variant is a three-customer line, 10 s between neighbours."""
    from mamut_routing_lib.models import BenchmarkInstanceVRPTW, BenchmarkInstanceCVRP

    common = dict(
        instance_name="line",
        instance_origin="Solomon1987",
        benchmark_name="Dimacs2021",
        num_customers=3,
        vehicle_capacity=10,
        coordinates=[(0, 0), (1, 0), (2, 0), (3, 0)],
        demands=[0, 1, 1, 1],
        depot=0,
        arc_costs=[[abs(i - j) * 10 for j in range(4)] for i in range(4)],
        metadata={"metric_variant": "fastest", "authors": "toy"},
    )
    if time_windows is None:
        instance = BenchmarkInstanceCVRP(**common)
    else:
        instance = BenchmarkInstanceVRPTW(**common, service_times=[0, 5, 5, 5], time_windows=time_windows)
    (tmp_path / "line_fastest.vrp.json").write_text(json.dumps(instance.model_dump(mode="json")))
    return {"folder": str(tmp_path), "files": {"vrp_json": {"fastest": "line_fastest.vrp.json"} if fastest else {"euclidean": "x"}}}


def test_the_timeline_names_its_clock_and_falls_back_to_constant_speed(tmp_path: Path) -> None:
    """A run the fastest travel times cannot clock still animates: no routes, and the reason."""
    from mamut_routing_tools.gui.server import _timeline_payload

    def timeline(record: dict, routes: list, metric: str) -> dict:
        return _timeline_payload(record, {"routes": routes, "metadata": {"metric": metric}})

    cvrp = timeline(_timeline_record(tmp_path, time_windows=None), [[1, 2, 3]], "euclidean")
    assert cvrp["clock"] == "free_flow_fastest" and cvrp["note"] is None  # travel times only: the default wording
    assert cvrp["routes"][0]["stops"] == [[1, 10.0, 10.0, 10.0], [2, 20.0, 20.0, 20.0], [3, 30.0, 30.0, 30.0]]

    loose = [(0, 1000), (0, 1000), (0, 1000), (0, 1000)]
    checked = timeline(_timeline_record(tmp_path, time_windows=loose), [[1, 2, 3]], "fastest")
    assert checked["clock"] == "checker" and checked["note"] is None  # the schedule the checker validated
    assert checked["routes"][0]["stops"][1] == [2, 25.0, 25.0, 30.0]  # service times are applied
    other = timeline(_timeline_record(tmp_path, time_windows=loose), [[1, 2, 3]], "euclidean")
    assert other["clock"] == "free_flow_fastest" and other["routes"] == checked["routes"]
    assert "service times" in other["note"] and "euclidean metric" in other["note"]  # not "no service times"

    tight = [(0, 1000), (0, 1000), (0, 1000), (0, 12)]  # customer 3 last is late under the fastest times
    missed = timeline(_timeline_record(tmp_path, time_windows=tight), [[1, 2, 3]], "shortest")
    assert missed["ok"] and missed["clock"] == "schematic" and missed["routes"] == []
    assert missed["note"].startswith("Constant speed (25 km/h)") and "shortest metric" in missed["note"]

    absent = timeline(_timeline_record(tmp_path, time_windows=None, fastest=False), [[1, 2, 3]], "euclidean")
    assert absent["ok"] and absent["clock"] == "schematic" and absent["routes"] == []
    assert "no fastest variant" in absent["note"]


def test_the_animation_plays_whatever_the_timeline_answers(client: TestClient) -> None:
    source = client.get("/static/workbench.js").text
    # The server's wording of the clock reaches the animation, and a failed request is a constant-speed animation.
    assert "if (timeline.note) clockLabels = { [timeline.clock]: timeline.note };" in source
    assert "clockLabels = { schematic: `Constant speed (25 km/h): no schedule for this run (${error.message})` };" in source
    assert "\n      clockLabels,\n" in source
    # The "needs WebGL2" notice is not a running animation.
    assert "return Boolean(routeAnimation && !routeAnimation.unavailable);" in source
    assert "dim: animationPlaying() ? 0.35 : 1," in source and "dim: routeAnimation ?" not in source


def test_displaying_a_run_refreshes_the_solver_list_for_its_metric(client: TestClient) -> None:
    """Setting the Metric select from a displayed run fires no change event: the solver support
    (FILO2 and AILS-II on road metrics) would stay that of the previous metric."""
    source = client.get("/static/workbench.js").text
    start = source.index('const metric = run.metadata?.metric || el("solve-metric").value || "fastest";')
    block = source[start : source.index("const rendered = await api(", start)]
    assert 'if (el("solve-metric").value !== metric) {' in block
    assert block.index('el("solve-metric").value = metric;') < block.index("loadSolvers()") and "syncVrpExportControls();" in block


def test_the_profile_cache_keeps_facts_not_instances(client: TestClient) -> None:
    import os

    from mamut_routing_lib.enums import ObjectiveFunction
    from mamut_routing_tools.gui import server

    instance_id = _generate(client)["instance_id"]
    assert client.get(f"/api/solvers?instance_id={instance_id}&metric=fastest").status_code == 200
    assert server._PROFILE_CACHE
    for (path, _mtime, _size), (profile, default) in server._PROFILE_CACHE.items():
        assert default is ObjectiveFunction.MONO_COST  # the default objective, not the instance and its matrix
        assert not hasattr(default, "arc_costs") and not hasattr(profile, "arc_costs")
    path = Path(next(iter(server._PROFILE_CACHE))[0])
    before = len(server._PROFILE_CACHE)
    assert server._cached_profile(path) is server._cached_profile(path) and len(server._PROFILE_CACHE) == before
    stat = path.stat()
    os.utime(path, ns=(stat.st_atime_ns, stat.st_mtime_ns + 1_000_000_000))  # the file changed: a new entry
    server._cached_profile(path)
    assert len(server._PROFILE_CACHE) == before + 1

